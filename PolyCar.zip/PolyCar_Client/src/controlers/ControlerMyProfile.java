package controlers;

import models.ModelUtilisateur;
import models.Utilisateur;
import views.ViewMyProfile;

public class ControlerMyProfile {

	ViewMyProfile view;
	public ControlerMyProfile(ModelUtilisateur modelProfile){
		this.view = new ViewMyProfile();
		
		Utilisateur user = modelProfile.getUser();
		if(user != null){
			this.view.labelLastName.setText(user.getLastName());
			this.view.labelFirstName.setText(user.getFirstName());
			this.view.labelAge.setText(String.valueOf(user.getAge()));
			this.view.labelEmail.setText(user.getEmail());
			this.view.labelTown.setText(user.getTown());
			this.view.labelAddress.setText(user.getAddress());
			this.view.labelPhoneNumber.setText(user.getPhoneNumber());
			this.view.labelTypeConduite.setText(user.getTypeConduite());
			this.view.labelTypeConducteur.setText(user.getTypeConducteur());
			this.view.labelNbSignalementConducteur.setText(String.valueOf(user.getNbSignalementConducteur()));
			this.view.labelNbSignalementPassager.setText(String.valueOf(user.getNbSignalementPassager()));
		}
	}
}
