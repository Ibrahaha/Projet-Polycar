package controlers;

import views.ViewLogin;

public class ControlerLogin {

	ViewLogin view;
	
	public ControlerLogin(){
		
		this.view = new ViewLogin();
	}
}
