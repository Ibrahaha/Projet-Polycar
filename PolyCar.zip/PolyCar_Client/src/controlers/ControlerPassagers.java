package controlers;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;

import internationalisation.Constantes;
import models.ModelUtilisateur;
import models.Utilisateur;
import network.InterfaceNetworkClient;
import views.ViewPassagers;

public class ControlerPassagers {

	ViewPassagers view;
	Utilisateur utilisateur;
	InterfaceNetworkClient networkClient;
	ModelUtilisateur modelUtilisateur;
	ModelUtilisateur modelProfile;
	
	public ControlerPassagers(ModelUtilisateur modelUtilisateur, ModelUtilisateur modelProfile, Utilisateur utilisateur, InterfaceNetworkClient networkClient){
		this.view = new ViewPassagers();
		this.utilisateur = utilisateur;
		this.networkClient = networkClient;
		this.modelUtilisateur = modelUtilisateur;
		this.modelProfile = modelProfile;
		
		this.view.labelUsername.setText(utilisateur.getNomPrenom());
		
		ActionShowProfile actionShowProfile = new ActionShowProfile();
		this.view.buttonProfile.setAction(actionShowProfile);
		
		ActionReport actionReport = new ActionReport();
		this.view.buttonReport.setAction(actionReport);
	}
	
	public class ActionShowProfile extends AbstractAction{
		
		public ActionShowProfile(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_SHOW_PROFILE));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			networkClient.getProfile(utilisateur);
			new ControlerProfile(modelUtilisateur, modelProfile, false, networkClient);
		}
	}
	
	public class ActionReport extends AbstractAction{
		
		public ActionReport(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_REPORT));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			networkClient.reportUserPassager(utilisateur);
		}
	}
}
