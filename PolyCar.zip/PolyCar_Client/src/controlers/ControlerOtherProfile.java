package controlers;

import java.awt.event.ActionEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.Action;

import internationalisation.Constantes;
import models.ModelUtilisateur;
import models.Utilisateur;
import network.InterfaceNetworkClient;
import views.ViewOtherProfile;

public class ControlerOtherProfile {

	ViewOtherProfile view;
	ModelUtilisateur modelUtilisateur;
	ModelUtilisateur modelProfile;
	InterfaceNetworkClient networkClient;
	
	public ControlerOtherProfile(ModelUtilisateur modelUtilisateur, ModelUtilisateur modelProfile, InterfaceNetworkClient networkClient){
		this.view = new ViewOtherProfile();
		this.modelUtilisateur = modelUtilisateur;
		this.modelProfile = modelProfile;
		this.networkClient = networkClient;
		
		Utilisateur user = modelProfile.getUser();
		if(user != null){
			this.view.labelLastName.setText(user.getLastName());
			this.view.labelFirstName.setText(user.getFirstName());
			this.view.labelAge.setText(String.valueOf(user.getAge()));
			this.view.labelEmail.setText(user.getEmail());
			this.view.labelTown.setText(user.getTown());
			this.view.labelAddress.setText(user.getAddress());
			this.view.labelPhoneNumber.setText(user.getPhoneNumber());
			this.view.labelTypeConduite.setText(user.getTypeConduite());
			this.view.labelTypeConducteur.setText(user.getTypeConducteur());
			this.view.labelNbSignalementConducteur.setText(String.valueOf(user.getNbSignalementConducteur()));
			this.view.labelNbSignalementPassager.setText(String.valueOf(user.getNbSignalementPassager()));
		}
		
		ActionFriend actionFriend = new ActionFriend();
		this.view.buttonFriend.setAction(actionFriend);		
		modelUtilisateur.addObserver(actionFriend);
		
		modelUtilisateur.init();
	}
	public class ActionFriend extends AbstractAction implements Observer{
		
		public ActionFriend(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_ADD_FRIEND));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(modelUtilisateur.getUser().isFriend(modelProfile.getUser())){
				networkClient.removeFriend(modelUtilisateur.getUser(), modelProfile.getUser());
			}
			else{
				networkClient.addFriend(modelUtilisateur.getUser(), modelProfile.getUser());
			}
		}	

		@Override
		public void update(Observable o, Object arg) {
			if(modelUtilisateur.getUser().isFriend(modelProfile.getUser())){
				view.buttonFriend.setSelected(true);
				this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_IS_FRIEND));
			}
			else{
				view.buttonFriend.setSelected(false);
				this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_ADD_FRIEND));
			}
			
		}
	}
}
