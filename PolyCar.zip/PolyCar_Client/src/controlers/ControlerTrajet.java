package controlers;

import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.AbstractAction;
import javax.swing.Action;

import internationalisation.Constantes;
import models.Etape;
import models.ModelTrajets;
import models.ModelUtilisateur;
import models.Trajet;
import models.Utilisateur;
import network.InterfaceNetworkClient;
import views.ViewTrajet;

public class ControlerTrajet {
	
	ModelTrajets modelTrajets;
	ModelUtilisateur modelUtilisateur;
	Trajet trajet;
	ViewTrajet view;
	boolean typeTrajet;
	InterfaceNetworkClient networkClient;
	
	public ControlerTrajet(ModelTrajets modelTrajets, ModelUtilisateur modelUtilisateur, ModelUtilisateur modelProfile, Trajet trajet, boolean typeTrajet, InterfaceNetworkClient networkClient){
		
		SimpleDateFormat jourFormatter = new SimpleDateFormat("EEEE dd MMMM yyyy");
		SimpleDateFormat heureFormatter = new SimpleDateFormat("h");
		SimpleDateFormat minuteFormatter = new SimpleDateFormat("mm");

		this.modelUtilisateur = modelUtilisateur;
		this.modelTrajets = modelTrajets;
		this.trajet = trajet;
		this.view = new ViewTrajet();
		this.typeTrajet = typeTrajet;
		this.networkClient = networkClient;
		
		String date = jourFormatter.format(this.trajet.dateDepart.getTime());
		date = date.substring(0,1).toUpperCase() + date.substring(1);
		this.view.labelDate.setText(date);
		
		String heureDepart = heureFormatter.format(this.trajet.dateDepart.getTime()) + "h" + minuteFormatter.format(this.trajet.dateDepart.getTime());
		this.view.labelHeureDepart.setText(heureDepart);
		this.view.labelVilleDepart.setText(trajet.villeDepart);
		
		String heureArrivee = heureFormatter.format(this.trajet.dateArrivee.getTime()) + "h" + minuteFormatter.format(this.trajet.dateArrivee.getTime());
		this.view.labelHeureArrivee.setText(heureArrivee);
		this.view.labelVilleArrivee.setText(trajet.villeArrivee);
	
		this.view.panelEtapes.removeAll();
		for(Etape etape: this.trajet.etapes){
			ControlerEtapesTrajet controler = new ControlerEtapesTrajet(etape);
			this.view.panelEtapes.add(controler.view);
		}
		
		String nbPassagersTotal = String.valueOf(this.trajet.nbPassagers);
		String nbPassagers = String.valueOf(this.trajet.listePassagers.size());
		this.view.labelNbPassagers.setText(nbPassagers + "/" + nbPassagersTotal);
		
		Calendar today = new GregorianCalendar();			
		this.view.panelPassagers.removeAll();
		if(!this.typeTrajet){
			for(Utilisateur passager: this.trajet.listePassagers){
				ControlerPassagers controler = new ControlerPassagers(modelUtilisateur, modelProfile, passager, networkClient);
				if(today.before(this.trajet.dateDepart)){
					controler.view.buttonReport.setVisible(false);
				}
				else{
					controler.view.buttonReport.setVisible(true);
				}
				this.view.panelPassagers.add(controler.view);
			}
		}
		
		this.view.labelPrix.setText(String.valueOf(this.trajet.prix));
		this.view.labelTypePrix.setText(this.trajet.choixPaiement);
		this.view.labelVehicule.setText(this.trajet.typeVehicule);
		
		if(today.before(this.trajet.dateDepart)){
			this.view.buttonReport.setVisible(false);
			this.view.buttonRemove.setVisible(false);
			this.view.buttonUnregisterCancel.setVisible(true);
		}
		else{
			if(typeTrajet){
				this.view.buttonReport.setVisible(true);
				this.view.buttonRemove.setVisible(false);
				this.view.buttonUnregisterCancel.setVisible(true);
			}
			else{
				this.view.buttonReport.setVisible(true);
				this.view.buttonRemove.setVisible(true);
				this.view.buttonUnregisterCancel.setVisible(false);
			}			
		}
		
		ActionReport actionReport = new ActionReport();
		this.view.buttonReport.setAction(actionReport);		
		
		AbstractAction actionUnregisterCancel;
		if(this.typeTrajet){
			actionUnregisterCancel = new ActionUnregister();
		}
		else{
			this.view.buttonReport.setVisible(false);
			actionUnregisterCancel = new ActionCancel();			
		}
		this.view.buttonUnregisterCancel.setAction(actionUnregisterCancel);
		ActionDelete actionDelete = new ActionDelete();
		this.view.buttonRemove.setAction(actionDelete);
	}
	
	public class ActionReport extends AbstractAction{

		public ActionReport(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_REPORT));
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			networkClient.reportUserConducteur(trajet.conducteur);
		}
	}
	
	public class ActionUnregister extends AbstractAction{

		public ActionUnregister(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_UNREGISTER));
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			networkClient.unregisterTrajet(trajet, modelUtilisateur.getUser());
		}
	}
	
	public class ActionDelete extends AbstractAction{

		public ActionDelete(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_DELETE));
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			networkClient.removeTrajet(trajet);
		}
	}
	
	public class ActionCancel extends AbstractAction{

		public ActionCancel(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_CANCEL));
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			networkClient.cancelTrajet(trajet);
		}
	}

}
