package controlers;

import views.ViewRegister;

public class ControlerRegister {
	
	ViewRegister view;
	
	public ControlerRegister(){
		
		this.view = new ViewRegister();
	}
}
