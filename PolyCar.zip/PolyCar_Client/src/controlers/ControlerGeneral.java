package controlers;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JPanel;

import internationalisation.Constantes;
import models.ModelLogin;
import models.ModelNotifications;
import models.ModelTrajets;
import models.ModelUtilisateur;
import models.Utilisateur;
import network.InterfaceNetworkClient;
import network.LoginException;
import network.RegisterException;
import views.ViewGeneral;

public class ControlerGeneral {
	
	ViewGeneral viewGeneral;
	ControlerLogin controlerLogin;
	ControlerRegister controlerRegister;
	InterfaceNetworkClient networkClient;
	ModelLogin modelLogin;	
	ModelUtilisateur modelUtilisateur;
	ModelTrajets modelTrajets;
	ModelUtilisateur modelProfile;
	ModelNotifications modelNotifications;
	ModelTrajets modelPropositionTrajet;

	public ControlerGeneral(ModelUtilisateur modelUtilisateur, ModelTrajets modelTrajets, ModelUtilisateur modelProfile, ModelNotifications modelNotifications, ModelTrajets modelPropositionTrajet, ModelLogin modelLogin, InterfaceNetworkClient networkClient){
		this.viewGeneral = new ViewGeneral();
		this.networkClient = networkClient;
		
		this.controlerLogin = new ControlerLogin();
		this.controlerRegister = new ControlerRegister();
		
		this.modelLogin = modelLogin;
		this.modelUtilisateur = modelUtilisateur;
		this.modelTrajets = modelTrajets;
		this.modelProfile = modelProfile;
		this.modelNotifications = modelNotifications;
		this.modelPropositionTrajet = modelPropositionTrajet;
		
		UpdateLogin updateLogin = new UpdateLogin();
		this.modelLogin.addObserver(updateLogin);
		
		ActionLogin actionLogin = new ActionLogin();
		this.controlerLogin.view.buttonLogin.setAction(actionLogin);
		
		ActionRegisterAsk actionRegisterAsk = new ActionRegisterAsk();
		this.controlerLogin.view.buttonRegister.setAction(actionRegisterAsk);
		
		ActionRegister actionRegister = new ActionRegister();
		this.controlerRegister.view.buttonRegister.setAction(actionRegister);
		
		ActionCancel actionCancel = new ActionCancel();
		this.controlerRegister.view.buttonCancel.setAction(actionCancel);
		
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new FlowLayout());
		mainPanel.add(this.controlerLogin.view);
		this.viewGeneral.setContentPane(mainPanel);
		
		this.viewGeneral.pack();
	}
	
	public class ActionLogin extends AbstractAction{

		public ActionLogin(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_LOGIN));
			this.putValue(Action.SHORT_DESCRIPTION, Constantes.resourceBundle.getString(Constantes.TOOLTIP_LOGIN));
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			String username = controlerLogin.view.tfUsername.getText();
			String password = String.valueOf(controlerLogin.view.pfPassword.getPassword());
			controlerLogin.view.labelError.setText("<html>");
			if(username.isEmpty() || password.isEmpty()){
				if(username.isEmpty()){
					controlerLogin.view.labelError.setText(controlerLogin.view.labelError.getText() + Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_LOGIN_USERNAME_EMPTY));
				}			
				if(username.isEmpty() && password.isEmpty()){
					controlerLogin.view.labelError.setText(controlerLogin.view.labelError.getText() + "<br>");
				}
				if(password.isEmpty()){				
					controlerLogin.view.labelError.setText(controlerLogin.view.labelError.getText() + Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_LOGIN_PASSWORD_EMPTY));
				}
			
				controlerLogin.view.labelError.setText(controlerLogin.view.labelError.getText() + "</html>");
			}
			else{
				
				try{
					networkClient.login(username, password);
				}
				catch (LoginException e){
					controlerLogin.view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_CONNECTION));
				}
			}
		}		
	}
	
	public class ActionRegisterAsk extends AbstractAction{

		
		public ActionRegisterAsk() {
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_REGISTER_ASK));
			this.putValue(Action.SHORT_DESCRIPTION, Constantes.resourceBundle.getString(Constantes.TOOLTIP_REGISTER_ASK));
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			JPanel mainPanel = new JPanel();
			mainPanel.setLayout(new FlowLayout());
			mainPanel.add(controlerRegister.view);
			viewGeneral.setContentPane(mainPanel);
			viewGeneral.repaint();
			viewGeneral.revalidate();
		}		
	}
	
	public class ActionRegister extends AbstractAction{
	
		public ActionRegister(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_REGISTER));
			this.putValue(Action.SHORT_DESCRIPTION, Constantes.resourceBundle.getString(Constantes.TOOLTIP_REGISTER));
		}
		
		@Override
		public void actionPerformed(ActionEvent arg0) {
			String lastName = controlerRegister.view.tfLastName.getText();
			String firstName = controlerRegister.view.tfFirstName.getText();
			String phoneNumber = controlerRegister.view.ftfPhoneNumber.getText();
			String username =  controlerRegister.view.tfUsername.getText();
			String email = controlerRegister.view.tfEmail.getText();
			String password = String.valueOf(controlerRegister.view.pfPassword.getPassword());
			
			if(lastName.isEmpty() || firstName.isEmpty() || phoneNumber.isEmpty() || username.isEmpty() || email.isEmpty() || password.isEmpty()){
				controlerRegister.view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_REGISTER_FIELD_EMPTY));
			}			
			else{
				
				Utilisateur user = new Utilisateur(username, password, lastName, firstName, phoneNumber, email);
				try{
					networkClient.register(user);
					JPanel mainPanel = new JPanel();
					mainPanel.setLayout(new FlowLayout());
					mainPanel.add(controlerLogin.view);
					viewGeneral.setContentPane(mainPanel);
					viewGeneral.repaint();
					viewGeneral.revalidate();
				}
				catch (RegisterException e){
					controlerRegister.view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_REGISTER));
				}
			}
		}
	}
	
	public class ActionCancel extends AbstractAction{
		
		public ActionCancel(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_CANCEL));
		}
		
		public void actionPerformed(ActionEvent arg0) {
			controlerRegister.view.tfLastName.setText("");
			controlerRegister.view.tfFirstName.setText("");
			controlerRegister.view.ftfPhoneNumber.setText("");
			controlerRegister.view.tfUsername.setText("");
			controlerRegister.view.tfEmail.setText("");
			controlerRegister.view.pfPassword.setText("");

			JPanel mainPanel = new JPanel();
			mainPanel.setLayout(new FlowLayout());
			mainPanel.add(controlerLogin.view);
			viewGeneral.setContentPane(mainPanel);
			viewGeneral.repaint();
			viewGeneral.revalidate();
		}
	}
	
	public class UpdateLogin implements Observer{

		@Override
		public void update(Observable arg0, Object arg1){
			if(modelLogin.getState()){
				JPanel mainPanel = new JPanel();
				mainPanel.setLayout(new FlowLayout());
				ControlerHome controlerHome = new ControlerHome(modelUtilisateur, modelTrajets, modelProfile, modelNotifications, modelPropositionTrajet, modelLogin, networkClient);
				mainPanel.add(controlerHome.view);
				viewGeneral.setContentPane(mainPanel);
				viewGeneral.repaint();
				viewGeneral.revalidate();
			}
			else{
				JPanel mainPanel = new JPanel();
				mainPanel.setLayout(new FlowLayout());
				mainPanel.add(controlerLogin.view);
				viewGeneral.setContentPane(mainPanel);
				viewGeneral.repaint();
				viewGeneral.revalidate();
			}
			
		}
	}
}
