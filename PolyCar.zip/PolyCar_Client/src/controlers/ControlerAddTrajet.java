package controlers;

import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.Action;

import internationalisation.Constantes;
import models.Etape;
import models.ModelEtapes;
import views.ViewAddTrajet;

public class ControlerAddTrajet {

	ViewAddTrajet view;
	ModelEtapes modelEtapes;
	
	public ControlerAddTrajet(ModelEtapes modelEtapes){
		
		this.view = new ViewAddTrajet();
		this.modelEtapes = modelEtapes;
		
		ActionAddEtape actionAddEtape = new ActionAddEtape();
		this.view.buttonAddEtape.setAction(actionAddEtape);
		
		UpdateEtape updateEtape = new UpdateEtape();
		this.modelEtapes.addObserver(updateEtape);
	}
	
	public class ActionAddEtape extends AbstractAction{
		
		public ActionAddEtape(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_ADD));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {

			try {
				String ville = view.tfEtapeNom.getText();
				String heure = view.tfEtapeHeure.getText();
				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
				Calendar date = new GregorianCalendar();
				date.setTime(sdf.parse(heure));
				Etape etape = new Etape(ville, date);
				modelEtapes.addEtape(etape);
				
			} catch (ParseException e) {
				view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_TIME));
			}
			
		}
	}
	
	public class UpdateEtape implements Observer{

		@Override
		public void update(Observable arg0, Object arg1) {
			List<Etape> listeEtapes = modelEtapes.getListEtape();
			view.panelEtapes.removeAll();
			int i = 0;
			for(Etape etape : listeEtapes){
				ControlerEtapeCreation controler = new ControlerEtapeCreation(modelEtapes, etape, i);
				view.panelEtapes.add(controler.view);
				i = i + 1;
			}
			view.panelEtapes.revalidate();
			view.panelEtapes.repaint();
			
			view.tfEtapeNom.setText("");
			view.tfEtapeHeure.setText("");
		}
		
	}
}
