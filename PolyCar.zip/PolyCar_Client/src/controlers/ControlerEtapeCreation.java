package controlers;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;

import internationalisation.Constantes;
import models.Etape;
import models.ModelEtapes;
import views.ViewEtapeCreation;

public class ControlerEtapeCreation {

	ViewEtapeCreation view;
	int numeroEtape;
	ModelEtapes modelEtapes;
	
	public ControlerEtapeCreation(ModelEtapes modelEtapes, Etape etape, int numeroEtape){
		this.modelEtapes = modelEtapes;
		this.numeroEtape = numeroEtape;
		
		this.view = new ViewEtapeCreation();
		this.view.labelEtape.setText(etape.getVille());
		this.view.labelHeure.setText(etape.getStringDate());
		
		ActionRemove actionRemove = new ActionRemove();
		this.view.buttonRemove.setAction(actionRemove);
	}
	
	public class ActionRemove extends AbstractAction{
		
		public ActionRemove(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_ERASE));
		}
		
		@Override
		public void actionPerformed(ActionEvent e){
			modelEtapes.removeEtape(numeroEtape);
		}
	}
}
