package controlers;

import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import javax.swing.AbstractAction;
import javax.swing.Action;

import internationalisation.Constantes;
import models.Etape;
import models.ModelUtilisateur;
import models.Trajet;
import network.InterfaceNetworkClient;
import views.ViewAddFindTrajet;
import views.ViewPropositionTrajet;

public class ControlerPropositionTrajet {

	ViewPropositionTrajet view;
	ModelUtilisateur modelUtilisateur;
	ModelUtilisateur modelProfile;
	Trajet trajet;
	InterfaceNetworkClient networkClient;
	ViewAddFindTrajet viewParent;
	
	public ControlerPropositionTrajet(Trajet trajet, ModelUtilisateur modelUtilisateur, ModelUtilisateur modelProfile, InterfaceNetworkClient networkClient, ViewAddFindTrajet viewParent){
		this.trajet = trajet;
		this.modelUtilisateur = modelUtilisateur;
		this.modelProfile = modelProfile;
		this.view = new ViewPropositionTrajet();
		this.networkClient = networkClient;
		this.viewParent = viewParent;
		
		SimpleDateFormat jourFormatter = new SimpleDateFormat("EEEE dd MMMM yyyy");
		SimpleDateFormat heureFormatter = new SimpleDateFormat("h");
		SimpleDateFormat minuteFormatter = new SimpleDateFormat("mm");
		
		String date = jourFormatter.format(this.trajet.dateDepart.getTime());
		date = date.substring(0,1).toUpperCase() + date.substring(1);
		this.view.labelDate.setText(date);
		
		String heureDepart = heureFormatter.format(this.trajet.dateDepart.getTime()) + "h" + minuteFormatter.format(this.trajet.dateDepart.getTime());
		this.view.labelHeureDepart.setText(heureDepart);
		this.view.labelVilleDepart.setText(trajet.villeDepart);
		
		String heureArrivee = heureFormatter.format(this.trajet.dateArrivee.getTime()) + "h" + minuteFormatter.format(this.trajet.dateArrivee.getTime());
		this.view.labelHeureArrivee.setText(heureArrivee);
		this.view.labelVilleArrivee.setText(trajet.villeArrivee);
	
		String nbPassagersTotal = String.valueOf(this.trajet.nbPassagers);
		String nbPassagers = String.valueOf(this.trajet.listePassagers.size());
		this.view.labelNbPassagers.setText(nbPassagers + "/" + nbPassagersTotal);
		
		this.view.panelEtapes.removeAll();
		for(Etape etape: this.trajet.etapes){
			ControlerEtapesTrajet controler = new ControlerEtapesTrajet(etape);
			this.view.panelEtapes.add(controler.view);
		}
				
		this.view.labelPrix.setText(String.valueOf(this.trajet.prix));
		this.view.labelTypePrix.setText(this.trajet.choixPaiement);
		this.view.labelVehicule.setText(this.trajet.typeVehicule);
		
		ActionShowProfile actionShowProfile = new ActionShowProfile();
		this.view.buttonShowProfile.setAction(actionShowProfile);
		
		ActionRegister actionRegister= new ActionRegister();
		this.view.buttonRegister.setAction(actionRegister);
	}
	
	public class ActionShowProfile extends AbstractAction{
		
		public ActionShowProfile(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_SHOW_PROFILE_CONDUCTEUR));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			networkClient.getProfile(trajet.conducteur);
			new ControlerProfile(modelUtilisateur, modelProfile, false, networkClient);
		}
	}
	
	public class ActionRegister extends AbstractAction{
		
		public ActionRegister(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_REGISTER));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			networkClient.registerTrajet(modelUtilisateur.getUser(), trajet);
			viewParent.dispose();
		}
	}
}
