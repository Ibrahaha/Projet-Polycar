package controlers;

import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.Action;

import internationalisation.Constantes;
import models.ModelTrajets;
import models.ModelUtilisateur;
import models.Trajet;
import network.InterfaceNetworkClient;
import views.ViewAddFindTrajet;
import views.ViewFindTrajet;

public class ControlerFindTrajet {
	
	ViewFindTrajet view;
	ModelUtilisateur modelUtilisateur;
	ModelUtilisateur modelProfile;
	ModelTrajets modelPropositionTrajet;
	InterfaceNetworkClient networkClient;
	ViewAddFindTrajet viewParent;
	
	public ControlerFindTrajet(ModelUtilisateur modelUtilisateur, ModelUtilisateur modelProfile, ModelTrajets modelPropositionTrajet, InterfaceNetworkClient networkClient, ViewAddFindTrajet viewParent){
		this.modelUtilisateur = modelUtilisateur;
		this.modelProfile = modelProfile;
		this.networkClient = networkClient;
		this.modelPropositionTrajet = modelPropositionTrajet;
		this.viewParent = viewParent;
		this.view = new ViewFindTrajet();
		
		ActionFind actionFind = new ActionFind();
		this.view.buttonSearch.setAction(actionFind);
		this.modelPropositionTrajet.addObserver(actionFind);
	}

	public class ActionFind extends AbstractAction implements Observer{
		
		public ActionFind(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_SEARCH));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String villeDep = view.tfVilleDepart.getText();
			String villeArr = view.tfVilleArrivee.getText();
			String jour = view.ftfDate.getText();
			
			if(villeDep.isEmpty() || villeArr.isEmpty() || jour.isEmpty()){
				view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_REGISTER_FIELD_EMPTY));
			}
			else{

				try {
					Calendar date = new GregorianCalendar();
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
					date.setTime(sdf.parse(jour));					
					networkClient.findTrajet(modelUtilisateur.getUser(), villeDep, villeArr, date);
				} 
				catch (ParseException e) {
					view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_DATE));
				}				
			}			
		}

		@Override
		public void update(Observable arg0, Object arg1) {
			
			List<Trajet> trajets = modelPropositionTrajet.getTrajets();
			view.panelResultat.removeAll();
			for(Trajet trajet : trajets){
				ControlerPropositionTrajet controler = new ControlerPropositionTrajet(trajet, modelUtilisateur, modelProfile, networkClient, viewParent);
				view.panelResultat.add(controler.view);
				view.panelResultat.revalidate();
				view.panelResultat.repaint();
			}
		}
	}
}
