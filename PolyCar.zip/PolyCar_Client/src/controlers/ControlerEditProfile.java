package controlers;

import internationalisation.Constantes;
import models.ModelUtilisateur;
import models.Utilisateur;
import views.ViewEditProfile;

public class ControlerEditProfile {

	ViewEditProfile view;
	ModelUtilisateur modelProfile;
	
	public ControlerEditProfile(ModelUtilisateur modelProfile){
		this.view = new ViewEditProfile();
		this.modelProfile = modelProfile;
		
		Utilisateur user = this.modelProfile.getUser();
		if(user != null){
			this.view.labelUsername.setText(user.getUsername());
			this.view.tfLastName.setText(user.getLastName());
			this.view.tfFirstName.setText(user.getFirstName());
			this.view.spinnerAge.setValue(user.getAge());
			this.view.pfPassword.setText(user.getPassword());
			this.view.tfEmail.setText(user.getEmail());
			this.view.tfTown.setText(user.getTown());
			this.view.tfAddress.setText(user.getAddress());
			this.view.ftfPhoneNumber.setText(user.getPhoneNumber());
			
			String typeConduite = user.getTypeConduite();
			if(typeConduite.equals(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_SLOW))){
				this.view.buttonConduiteLente.setSelected(true);
				this.view.buttonConduiteNormale.setSelected(false);
				this.view.buttonConduiteRapide.setSelected(false);
			}
			else if(typeConduite.equals(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_NORMAL))){
				this.view.buttonConduiteNormale.setSelected(true);
				this.view.buttonConduiteLente.setSelected(false);
				this.view.buttonConduiteRapide.setSelected(false);
			}
			else if(typeConduite.equals(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_FAST))){
				this.view.buttonConduiteRapide.setSelected(true);
				this.view.buttonConduiteLente.setSelected(false);
				this.view.buttonConduiteNormale.setSelected(false);
			}
			
			String typeConducteur = user.getTypeConducteur();
			if(typeConducteur.equals(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_MUSIQUE))){
				this.view.buttonConducteurMusique.setSelected(true);
				this.view.buttonConducteurBavarder.setSelected(false);
				this.view.buttonConducteurInformation.setSelected(false);
				this.view.buttonConducteurConcentre.setSelected(false);
			}
			else if(typeConducteur.equals(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_TALKATIVE))){
				this.view.buttonConducteurBavarder.setSelected(true);
				this.view.buttonConducteurMusique.setSelected(false);
				this.view.buttonConducteurInformation.setSelected(false);
				this.view.buttonConducteurConcentre.setSelected(false);
			}
			else if(typeConducteur.equals(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_INFORMATION))){
				this.view.buttonConducteurInformation.setSelected(true);
				this.view.buttonConducteurMusique.setSelected(false);
				this.view.buttonConducteurBavarder.setSelected(false);
				this.view.buttonConducteurConcentre.setSelected(false);
			}
			else if(typeConducteur.equals(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_CONCENTRATE))){
				this.view.buttonConducteurConcentre.setSelected(true);
				this.view.buttonConducteurMusique.setSelected(false);
				this.view.buttonConducteurBavarder.setSelected(false);
				this.view.buttonConducteurInformation.setSelected(false);
			}
		}
	}
}
