package controlers;

import models.Etape;
import views.ViewEtapesTrajet;

public class ControlerEtapesTrajet {

	ViewEtapesTrajet view;
	
	public ControlerEtapesTrajet(Etape etape){
		
		this.view = new ViewEtapesTrajet();		
		
		this.view.labelEtape.setText(etape.getVille());		
		this.view.labelHeure.setText(etape.getStringDate());
	}
}
