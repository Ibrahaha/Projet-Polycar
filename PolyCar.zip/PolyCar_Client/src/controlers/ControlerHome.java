package controlers;

import java.awt.event.ActionEvent;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.Action;

import models.ModelLogin;
import models.ModelNotifications;
import models.ModelTrajets;
import models.ModelUtilisateur;
import models.Notification;
import models.Trajet;
import network.InterfaceNetworkClient;
import views.ViewHome;

public class ControlerHome {
	
	ViewHome view;
	ModelNotifications modelNotifications;
	ModelTrajets modelTrajets;
	ModelUtilisateur modelUtilisateur;
	ModelUtilisateur modelProfile;
	ModelTrajets modelPropositionTrajet;
	ModelLogin modelLogin;
	InterfaceNetworkClient networkClient;
	
	public ControlerHome(ModelUtilisateur modelUtilisateur, ModelTrajets modelTrajets,ModelUtilisateur modelProfile, ModelNotifications modelNotifications,  ModelTrajets modelPropositionTrajet, ModelLogin modelLogin, InterfaceNetworkClient networkClient){
		
		this.modelNotifications = modelNotifications;
		this.modelTrajets = modelTrajets;
		this.modelUtilisateur = modelUtilisateur;
		this.modelProfile = modelProfile;
		this.networkClient = networkClient;
		this.modelPropositionTrajet = modelPropositionTrajet;
		this.modelLogin = modelLogin;
		
		this.view = new ViewHome();	
		
		ActionClearNotification actionClearNotification = new ActionClearNotification();
		this.view.buttonClearNotification.setAction(actionClearNotification);
		
		modelNotifications.addObserver(actionClearNotification);
		
		UpdateNotification updateNotification = new UpdateNotification();
		modelNotifications.addObserver(updateNotification);
		
		ActionMyProfile actionMyProfile = new ActionMyProfile();
		this.view.buttonMyProfil.setAction(actionMyProfile);
		
		ActionAddTrajet actionAddTrajet = new ActionAddTrajet();
		this.view.buttonAddTrajet.setAction(actionAddTrajet);
		
		ActionFindTrajet actionFindTrajet = new ActionFindTrajet();
		this.view.buttonFindTrajet.setAction(actionFindTrajet);
		
		ActionDisconnect actionDisconnect = new ActionDisconnect();
		this.view.buttonDisconnect.setAction(actionDisconnect);
		
		ActionShowTrajet actionShowTrajet = new ActionShowTrajet();
		this.view.buttonSelectTypeTrajet.setAction(actionShowTrajet);
		
		UpdateTrajets updateTrajets = new UpdateTrajets();
		modelTrajets.addObserver(updateTrajets);
		
		UpdateName updateName = new UpdateName();
		modelUtilisateur.addObserver(updateName);
	}
	
	public class ActionClearNotification extends AbstractAction implements Observer{
		
		public ActionClearNotification(){
			
			this.putValue(Action.NAME, "Effacer");
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			networkClient.deleteNotifications(modelNotifications.getNotifications());
		}

		@Override
		public void update(Observable arg0, Object arg1) {
			if(modelNotifications.isEmpty()){
				this.setEnabled(false);
			}
			else{
				this.setEnabled(true);
			}
		}		
	}
	
	public class UpdateNotification implements Observer{

		@Override
		public void update(Observable o, Object arg) {
			
			view.taNotifications.setText("");
			List<Notification> notifications = modelNotifications.getNotifications();
			for(Notification notication : notifications){
				String strNotification = notication.getText();
				view.taNotifications.setText(view.taNotifications.getText() + strNotification + "\n");
			}
		}
	}
	
	public class UpdateTrajets implements Observer{

		@Override
		public void update(Observable arg0, Object arg1) {
			List<Trajet> trajets = modelTrajets.getTrajets();
			view.panelTrajets.removeAll();
			for(Trajet trajet : trajets){
				boolean typeTrajets = true;
				if(((String)view.cbTrajets.getSelectedItem()).equals("Conducteur")){
					typeTrajets = false;
				}
				ControlerTrajet controler = new ControlerTrajet(modelTrajets, modelUtilisateur, modelProfile, trajet, typeTrajets, networkClient);
				view.panelTrajets.add(controler.view);
			}
			view.panelTrajets.revalidate();
			view.panelTrajets.repaint();
		}
	}
	
	public class UpdateName implements Observer{

		@Override
		public void update(Observable arg0, Object arg1) {
			String name = modelUtilisateur.getName();
			view.labelHelloName.setText(name);			
		}
	}
	
	public class ActionMyProfile extends AbstractAction{
		
		public ActionMyProfile(){
			this.putValue(Action.NAME, "Profil");
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			networkClient.getProfile(modelUtilisateur.getUser());
			new ControlerProfile(modelUtilisateur, modelProfile, true, networkClient);
		}
	}
	
	public class ActionAddTrajet extends AbstractAction{
		
		public ActionAddTrajet(){
			this.putValue(Action.NAME, "Proposer un trajet");
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			new ControlerAddFindTrajet(modelUtilisateur, modelProfile, modelPropositionTrajet, networkClient, true);
		}
	}
	
	public class ActionFindTrajet extends AbstractAction{
		
		public ActionFindTrajet(){
			this.putValue(Action.NAME, "Trouver un trajet");
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			new ControlerAddFindTrajet(modelUtilisateur, modelProfile, modelPropositionTrajet, networkClient, false);
		}
	}
	
	public class ActionDisconnect extends AbstractAction{
		
		public ActionDisconnect(){
			this.putValue(Action.NAME, "Deconnexion");
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			modelLogin.setFalse();
		}
	}
	
	public class ActionShowTrajet extends AbstractAction{
		
		public ActionShowTrajet(){
			this.putValue(Action.NAME, "S�lectionner");
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			if(((String)view.cbTrajets.getSelectedItem()).equals("Conducteur")){
				networkClient.getTrajetsConducteur(modelUtilisateur.getUser());
			}
			else{
				networkClient.getTrajetsPassager(modelUtilisateur.getUser());
			}
		}
	}
}
