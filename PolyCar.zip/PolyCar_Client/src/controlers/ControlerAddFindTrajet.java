package controlers;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JPanel;

import internationalisation.Constantes;
import models.Etape;
import models.ModelEtapes;
import models.ModelTrajets;
import models.ModelUtilisateur;
import models.Trajet;
import network.InterfaceNetworkClient;
import views.ViewAddFindTrajet;

public class ControlerAddFindTrajet {

	ViewAddFindTrajet view;
	ModelUtilisateur modelUtilisateur;
	InterfaceNetworkClient networkClient;
	ControlerAddTrajet controlerAddTrajet;
	ModelEtapes modelEtapes;
	
	public ControlerAddFindTrajet(ModelUtilisateur modelUtilisateur, ModelUtilisateur modelProfile, ModelTrajets modelPropositionTrajet, InterfaceNetworkClient networkClient, boolean typeAddFindTrajet){
	
		this.view = new ViewAddFindTrajet();
		this.modelUtilisateur = modelUtilisateur;
		this.networkClient = networkClient;
		this.modelEtapes = new ModelEtapes();
		
		this.controlerAddTrajet = new ControlerAddTrajet(this.modelEtapes);
		ControlerFindTrajet controlerFindTrajet = new ControlerFindTrajet(modelUtilisateur, modelProfile, modelPropositionTrajet, networkClient, this.view);
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new FlowLayout());		
		
		if(typeAddFindTrajet){
			mainPanel.add(controlerAddTrajet.view);
		}
		else{
			mainPanel.add(controlerFindTrajet.view);
			view.setPreferredSize(new Dimension(1000, 520));
		}
		
		ActionConfirm actionConfirm = new ActionConfirm();
		controlerAddTrajet.view.buttonConfirm.setAction(actionConfirm);
		
		ActionCancel actionCancel = new ActionCancel();
		controlerAddTrajet.view.buttonCancel.setAction(actionCancel);
		controlerFindTrajet.view.buttonCancel.setAction(actionCancel);
		
		this.view.setContentPane(mainPanel);
		this.view.pack();
	}
	
	@SuppressWarnings("serial")
	public class ActionConfirm extends AbstractAction{
		
		public ActionConfirm(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_CONFIRM));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			String villeDepart = controlerAddTrajet.view.tfVilleDepart.getText();
			String villeArrivee = controlerAddTrajet.view.tfVilleArrivee.getText();
			String heureDepart = controlerAddTrajet.view.ftfHeureDepart.getText();
			String heureArrivee = controlerAddTrajet.view.ftfHeureArrivee.getText();
			String date = controlerAddTrajet.view.ftfDate.getText();
			List<Etape> etapes = modelEtapes.getListEtape();
			int	nbPassagers = (int) controlerAddTrajet.view.spinnerNbPassagers.getValue();
			int	prix = (int) controlerAddTrajet.view.spinnerPrix.getValue();
			String typePrix = controlerAddTrajet.view.cbTypePrix.getSelectedItem().toString();
			String typeVehicule = controlerAddTrajet.view.cbTypeVehicule.getSelectedItem().toString();
			controlerAddTrajet.view.labelError.setText("");
			if(villeDepart.isEmpty() || villeArrivee.isEmpty() || heureDepart.charAt(0) == ' ' || heureArrivee.charAt(0) == ' ' || date.charAt(0) == ' '){
				
				controlerAddTrajet.view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_TRAJET_EMPTY_FIELD));
			}
			else{
				
				Calendar dateDepart = new GregorianCalendar();
				Calendar dateArrivee = new GregorianCalendar();
				
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
					
					dateDepart.setTime(sdf.parse(heureDepart + " " + date));
				} 
				catch (ParseException e) {
					controlerAddTrajet.view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_TIME_DATE));
				}
				
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
					
					dateArrivee.setTime(sdf.parse(heureArrivee + " " + date));
				} 
				catch (ParseException e) {
					controlerAddTrajet.view.labelError.setText(Constantes.resourceBundle.getString(Constantes.LABEL_ERROR_TIME_DATE));
				}
				
				Trajet trajet = new Trajet(villeDepart, villeArrivee, dateDepart, dateArrivee, nbPassagers, prix, typeVehicule, typePrix, modelUtilisateur.getUser(), etapes);
				networkClient.addTrajet(trajet);
				view.dispose();
			}
		}
	}
	
	public class ActionCancel extends AbstractAction{
		
		public ActionCancel(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_CANCEL));
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			view.dispose();			
		}
	}
	
}
