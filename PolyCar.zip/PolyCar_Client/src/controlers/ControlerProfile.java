
package controlers;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JPanel;

import internationalisation.Constantes;
import models.ModelUtilisateur;
import models.Utilisateur;
import network.InterfaceNetworkClient;
import views.ViewProfile;

public class ControlerProfile {
	
	ViewProfile view;
	InterfaceNetworkClient networkClient;
	ControlerEditProfile controlerEditProfile;
	
	public ControlerProfile(ModelUtilisateur modelUtilisateur, ModelUtilisateur modelProfile, boolean typeProfile, InterfaceNetworkClient networkClient){
		
		this.view = new ViewProfile();
		ControlerMyProfile controlerMyProfile = new ControlerMyProfile(modelProfile);
		this.controlerEditProfile = new ControlerEditProfile(modelProfile);
		this.networkClient = networkClient;
		ControlerOtherProfile controlerOtherProfile = new ControlerOtherProfile(modelUtilisateur, modelProfile, this.networkClient);
		
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new FlowLayout());		
		
		if(typeProfile){
			mainPanel.add(controlerMyProfile.view);
		}
		else{
			mainPanel.add(controlerOtherProfile.view);	
		}
		
		ActionEditProfile actionEditProfile = new ActionEditProfile();
		controlerMyProfile.view.buttonEdit.setAction(actionEditProfile);
		
		ActionValidate actionValidate = new ActionValidate();
		controlerMyProfile.view.buttonValidate.setAction(actionValidate);
		controlerOtherProfile.view.buttonValidate.setAction(actionValidate);
		
		ActionConfirmEdit actionConfirmEdit = new ActionConfirmEdit();
		controlerEditProfile.view.buttonConfirm.setAction(actionConfirmEdit);
		
		this.view.setContentPane(mainPanel);
		this.view.pack();
	}
	
	public class ActionEditProfile extends AbstractAction{
		
		public ActionEditProfile(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_EDIT));
		}
	
		@Override
		public void actionPerformed(ActionEvent arg0) {
			JPanel mainPanel = new JPanel();
			mainPanel.setLayout(new FlowLayout());
			mainPanel.add(controlerEditProfile.view);
			view.setContentPane(mainPanel);
			view.repaint();
			view.revalidate();			
		}
	}
	
	public class ActionValidate extends AbstractAction{
		
		public ActionValidate(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_VALIDATE));
		}
	
		@Override
		public void actionPerformed(ActionEvent arg0) {
			view.dispose();
		}
	}

	public class ActionConfirmEdit extends AbstractAction{
		
		public ActionConfirmEdit(){
			this.putValue(Action.NAME, Constantes.resourceBundle.getString(Constantes.BUTTON_CONFIRM));
		}
	
		@Override
		public void actionPerformed(ActionEvent arg0) {
			
			String username = controlerEditProfile.view.labelUsername.getText();
			String lastName = controlerEditProfile.view.tfLastName.getText();
			String firstName = controlerEditProfile.view.tfFirstName.getText();
			String phoneNumber = controlerEditProfile.view.ftfPhoneNumber.getText();
			String email = controlerEditProfile.view.tfEmail.getText();
			String password = String.valueOf(controlerEditProfile.view.pfPassword.getPassword());
			int age = (int) controlerEditProfile.view.spinnerAge.getValue();
			String address = controlerEditProfile.view.tfAddress.getText();
			String town = controlerEditProfile.view.tfTown.getText();
			
			String typeConduite = "";
			if(controlerEditProfile.view.buttonConduiteLente.isSelected()){
				typeConduite = controlerEditProfile.view.buttonConduiteLente.getText();
			}
			else if(controlerEditProfile.view.buttonConduiteNormale.isSelected()){
				typeConduite = controlerEditProfile.view.buttonConduiteNormale.getText();
			}
			else if(controlerEditProfile.view.buttonConduiteRapide.isSelected()){
				typeConduite = controlerEditProfile.view.buttonConduiteRapide.getText();
			}
			
			String typeConducteur = "";
			if(controlerEditProfile.view.buttonConducteurMusique.isSelected()){
				typeConducteur = controlerEditProfile.view.buttonConducteurMusique.getText();
			}
			else if(controlerEditProfile.view.buttonConducteurBavarder.isSelected()){
				typeConducteur = controlerEditProfile.view.buttonConducteurBavarder.getText();
			}
			else if(controlerEditProfile.view.buttonConducteurInformation.isSelected()){
				typeConducteur = controlerEditProfile.view.buttonConducteurInformation.getText();
			}
			else if(controlerEditProfile.view.buttonConducteurConcentre.isSelected()){
				typeConducteur = controlerEditProfile.view.buttonConducteurConcentre.getText();
			}

				
			Utilisateur user = new Utilisateur(username, password, lastName, firstName, phoneNumber, email, age, town, address, typeConducteur, typeConduite);
			
			networkClient.updateUtilisateur(user);
			view.dispose();
		}
	}
}
