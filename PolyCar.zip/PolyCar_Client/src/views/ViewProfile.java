package views;

import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import internationalisation.Constantes;

public class ViewProfile extends JFrame {

	public ViewProfile(){
		
		this.setIconImage(new ImageIcon(this.getClass().getClassLoader().getResource("Images/icon_polycar.png")).getImage());
		this.setResizable(false);
		this.setPreferredSize(new Dimension(480, 450));
		this.setTitle(Constantes.resourceBundle.getString(Constantes.WINDOW_TITLE_PROFILE));		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
