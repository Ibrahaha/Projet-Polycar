package views;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ViewPassagers extends JPanel {

	public JLabel labelUsername;
	public JButton buttonProfile;
	public JButton buttonReport;
	
	public ViewPassagers(){
		
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		this.labelUsername = new JLabel();
		this.buttonProfile = new JButton();
		this.buttonProfile.setBackground(new Color(66, 139, 202));
		this.buttonProfile.setForeground(Color.WHITE);
		this.buttonReport = new JButton();
		this.buttonReport.setBackground(new Color(255, 255, 255));
		
		panelContainer.add(this.labelUsername);
		panelContainer.add(this.buttonProfile);
		panelContainer.add(this.buttonReport);
		
		this.add(panelContainer);
	}
}
