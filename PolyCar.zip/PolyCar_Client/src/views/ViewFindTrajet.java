package views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.text.ParseException;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import internationalisation.Constantes;

public class ViewFindTrajet extends JPanel {
	
	public JTextField tfVilleDepart;
	public JTextField tfVilleArrivee;
	public JFormattedTextField ftfDate;
	public JButton buttonSearch;
	public JButton buttonCancel;
	public JPanel panelResultat;
	public JLabel labelError;
	
	public ViewFindTrajet(){
		
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new BoxLayout(panelContainer, BoxLayout.Y_AXIS));
		
		JPanel panelError = new JPanel();
		panelError.setLayout(new FlowLayout());
		this.labelError = new JLabel();
		this.labelError.setForeground(Color.RED);
		panelError.add(this.labelError);
		
		JPanel panelFieldContainer = new JPanel();
		panelFieldContainer.setLayout(new GridLayout(2, 2));
		
		JPanel panelFieldDepart = new JPanel();
		panelFieldDepart.setLayout(new BoxLayout(panelFieldDepart, BoxLayout.Y_AXIS));
		JLabel labelTitleDepart = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TOWN_DEPART));
		this.tfVilleDepart = new JTextField(10);
		panelFieldDepart.add(labelTitleDepart);
		panelFieldDepart.add(this.tfVilleDepart);
		
		JPanel panelFieldDate = new JPanel();
		panelFieldDate.setLayout(new BoxLayout(panelFieldDate, BoxLayout.Y_AXIS));
		JLabel labelTitleDate = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_DATE));
		try {
			MaskFormatter formatter = new MaskFormatter("##/##/####");
			this.ftfDate = new JFormattedTextField(formatter);
		} catch (ParseException e) {
			this.ftfDate = new JFormattedTextField();
		}
		panelFieldDate.add(labelTitleDate);
		panelFieldDate.add(this.ftfDate);
		
		JPanel panelFieldArrivee = new JPanel();
		panelFieldArrivee.setLayout(new BoxLayout(panelFieldArrivee, BoxLayout.Y_AXIS));
		JLabel labelTitleArrivee = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TOWN_ARRIVEE));
		this.tfVilleArrivee = new JTextField(10);
		panelFieldArrivee.add(labelTitleArrivee);
		panelFieldArrivee.add(this.tfVilleArrivee);
		
		JPanel panelFieldButton = new JPanel();
		panelFieldButton.setLayout(new FlowLayout());
		this.buttonSearch = new JButton();
		this.buttonSearch.setBackground(new Color(66, 139, 202));
		this.buttonSearch.setForeground(Color.WHITE);
		panelFieldButton.add(this.buttonSearch);
		
		panelFieldContainer.add(panelFieldDepart);
		panelFieldContainer.add(panelFieldDate);
		panelFieldContainer.add(panelFieldArrivee);
		panelFieldContainer.add(panelFieldButton);
		
		JPanel panelResultat = new JPanel();
		panelResultat.setLayout(new FlowLayout());
		this.panelResultat = new JPanel();
		this.panelResultat.setLayout(new BoxLayout(this.panelResultat, BoxLayout.Y_AXIS));
		JScrollPane scrollEtape = new JScrollPane(this.panelResultat);
		scrollEtape.setPreferredSize(new Dimension(850, 300));
		panelResultat.add(scrollEtape);
		
		JPanel panelButton = new JPanel();
		panelButton.setLayout(new FlowLayout());
		this.buttonCancel = new JButton();
		this.buttonCancel.setBackground(new Color(255, 255, 255));
		panelButton.add(this.buttonCancel);
		
		panelContainer.add(panelError);
		panelContainer.add(panelFieldContainer);
		panelContainer.add(panelResultat);
		panelContainer.add(panelButton);
		
		this.add(panelContainer);
	}
}
