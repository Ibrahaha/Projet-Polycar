package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.text.ParseException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.text.MaskFormatter;

import internationalisation.Constantes;

public class ViewEditProfile extends JPanel {

	public JTextField tfLastName;
	public JTextField tfFirstName;
	public JFormattedTextField ftfPhoneNumber;
	public JLabel labelUsername;
	public JPasswordField pfPassword;
	public JTextField tfEmail;
	public JSpinner spinnerAge;
	public JTextField tfTown;
	public JTextField tfAddress;
	public JButton buttonConfirm;
	public JRadioButton buttonConduiteLente;
	public JRadioButton buttonConduiteNormale;
	public JRadioButton buttonConduiteRapide;
	public JRadioButton buttonConducteurMusique;
	public JRadioButton buttonConducteurBavarder;
	public JRadioButton buttonConducteurInformation;
	public JRadioButton buttonConducteurConcentre;
	
	public ViewEditProfile(){
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new BoxLayout(panelContainer, BoxLayout.Y_AXIS));
		
		JPanel panelField_Title = new JPanel();
		panelField_Title.setLayout(new FlowLayout(FlowLayout.CENTER));
		JLabel labelField_Title = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TITLE_PROFILE) + " -");
		labelField_Title.setFont(new Font(labelField_Title.getFont().getFontName(), Font.PLAIN, labelField_Title.getFont().getSize() + 10));
		this.labelUsername = new JLabel();
		this.labelUsername.setFont(new Font(this.labelUsername.getFont().getFontName(), Font.ITALIC, this.labelUsername.getFont().getSize() + 10));
		panelField_Title.add(labelField_Title);
		panelField_Title.add(this.labelUsername);
		
		JPanel panelField_1 = new JPanel();
		panelField_1.setLayout(new BorderLayout());
		JPanel panelField_1_Name = new JPanel();
		panelField_1_Name.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldLastName = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_LAST_NAME));
		this.tfLastName = new JTextField(10);		
		JLabel labelFieldFirstName = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_FIRST_NAME));
		this.tfFirstName = new JTextField(10);
		panelField_1_Name.add(labelFieldLastName);
		panelField_1_Name.add(this.tfLastName);
		panelField_1_Name.add(labelFieldFirstName);
		panelField_1_Name.add(this.tfFirstName);
		panelField_1.add(BorderLayout.WEST, panelField_1_Name);
		
		JPanel panelField_2 = new JPanel();
		panelField_2.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldAge = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_AGE));
		SpinnerNumberModel spinnerModel = new SpinnerNumberModel(1, 1, 99, 1);
		this.spinnerAge = new JSpinner(spinnerModel);
		JLabel labelFieldPassword = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_PASSWORD));
		this.pfPassword = new JPasswordField(20);
		panelField_2.add(labelFieldAge);
		panelField_2.add(this.spinnerAge);
		panelField_2.add(labelFieldPassword);
		panelField_2.add(this.pfPassword);
		
		JPanel panelField_3 = new JPanel();
		panelField_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldEmail = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_EMAIL));
		this.tfEmail = new JTextField(20);
		panelField_3.add(labelFieldEmail);
		panelField_3.add(this.tfEmail);		
		
		JPanel panelField_4 = new JPanel();
		panelField_4.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldTown = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TOWN));
		this.tfTown = new JTextField(10);
		JLabel labelFieldAddress = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_ADDRESS));
		this.tfAddress = new JTextField(20);
		panelField_4.add(labelFieldTown);
		panelField_4.add(this.tfTown);
		panelField_4.add(labelFieldAddress);
		panelField_4.add(this.tfAddress);
		
		JPanel panelField_5 = new JPanel();
		panelField_5.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldPhoneNumber = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_PHONE_NUMBER));
		try {
			MaskFormatter formatter = new MaskFormatter("## ## ## ## ##");
			this.ftfPhoneNumber = new JFormattedTextField(formatter);
		} catch (ParseException e) {
			this.ftfPhoneNumber = new JFormattedTextField();
		}
		panelField_5.add(labelFieldPhoneNumber);
		panelField_5.add(this.ftfPhoneNumber);
		
		
		JPanel panelField_6 = new JPanel();
		panelField_6.setLayout(new FlowLayout());
		
		JPanel panelField_6_Conduite = new JPanel();
		panelField_6_Conduite.setLayout(new BoxLayout(panelField_6_Conduite, BoxLayout.Y_AXIS));
		JLabel labelFieldTypeConduite = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TYPE_CONDUITE));
		ButtonGroup groupeConduite = new ButtonGroup();
		this.buttonConduiteLente = new JRadioButton(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_SLOW));
		this.buttonConduiteNormale = new JRadioButton(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_NORMAL));
		this.buttonConduiteRapide = new JRadioButton(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_FAST));
		groupeConduite.add(this.buttonConduiteLente);
		groupeConduite.add(this.buttonConduiteNormale);
		groupeConduite.add(this.buttonConduiteRapide);
		panelField_6_Conduite.add(labelFieldTypeConduite);
		panelField_6_Conduite.add(this.buttonConduiteLente);
		panelField_6_Conduite.add(this.buttonConduiteNormale);
		panelField_6_Conduite.add(this.buttonConduiteRapide);
		panelField_6_Conduite.setBorder(BorderFactory.createEmptyBorder(0,0,0,20));
		
		JPanel panelField_6_Conducteur= new JPanel();
		panelField_6_Conducteur.setLayout(new BoxLayout(panelField_6_Conducteur, BoxLayout.Y_AXIS));	
		JLabel labelFieldTypeConducteur = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TYPE_CONDUCTEUR));
		ButtonGroup groupeConducteur = new ButtonGroup();
		this.buttonConducteurMusique = new JRadioButton(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_MUSIQUE));
		this.buttonConducteurBavarder = new JRadioButton(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_TALKATIVE));
		this.buttonConducteurInformation = new JRadioButton(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_INFORMATION));
		this.buttonConducteurConcentre = new JRadioButton(Constantes.resourceBundle.getString(Constantes.RADIO_BUTTON_CONCENTRATE));
		groupeConducteur.add(this.buttonConducteurMusique);
		groupeConducteur.add(this.buttonConducteurBavarder);
		groupeConducteur.add(this.buttonConducteurInformation);
		groupeConducteur.add(this.buttonConducteurConcentre);
		panelField_6_Conducteur.add(labelFieldTypeConducteur);
		panelField_6_Conducteur.add(this.buttonConducteurMusique);
		panelField_6_Conducteur.add(this.buttonConducteurBavarder);
		panelField_6_Conducteur.add(this.buttonConducteurInformation);
		panelField_6_Conducteur.add(this.buttonConducteurConcentre);

		panelField_6.add(panelField_6_Conduite);
		panelField_6.add(panelField_6_Conducteur);
		panelField_6.setBorder(BorderFactory.createEmptyBorder(0,0,20,0));
		
		JPanel panelField_Validate = new JPanel();
		panelField_Validate.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.buttonConfirm = new JButton();
		this.buttonConfirm.setBackground(new Color(66, 139, 202));
		this.buttonConfirm.setForeground(Color.WHITE);
		panelField_Validate.add(this.buttonConfirm);
		
		panelContainer.add(panelField_Title);
		panelContainer.add(panelField_1);
		panelContainer.add(panelField_2);
		panelContainer.add(panelField_3);
		panelContainer.add(panelField_4);
		panelContainer.add(panelField_5);
		panelContainer.add(panelField_6);
		panelContainer.add(panelField_Validate);
		
		this.add(panelContainer);
	}
}
