package views;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import internationalisation.Constantes;

public class ViewGeneral extends JFrame {

	public ViewGeneral(){
		
		this.setIconImage(new ImageIcon(this.getClass().getClassLoader().getResource("Images/icon_polycar.png")).getImage());
		this.setResizable(false);
		this.setPreferredSize(new Dimension(1200, 525));
		this.setTitle(Constantes.resourceBundle.getString(Constantes.WINDOW_TITLE));		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
