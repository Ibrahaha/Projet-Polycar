package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JToggleButton;

import internationalisation.Constantes;

public class ViewOtherProfile extends JPanel {

	public JLabel labelLastName;
	public JLabel labelFirstName;
	public JLabel labelPhoneNumber;
	public JLabel labelUsername;
	public JLabel labelEmail;
	public JLabel labelAge;
	public JLabel labelTown;
	public JLabel labelAddress;
	public JLabel labelTypeConduite;
	public JLabel labelTypeConducteur;
	public JLabel labelNbSignalementConducteur;
	public JLabel labelNbSignalementPassager;
	public JToggleButton buttonFriend;
	public JButton buttonValidate;
	
	public ViewOtherProfile(){
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new BoxLayout(panelContainer, BoxLayout.Y_AXIS));
		
		JPanel panelField_Title = new JPanel();
		panelField_Title.setLayout(new FlowLayout(FlowLayout.CENTER));
		JLabel labelField_Title = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TITLE_PROFILE));
		labelField_Title.setFont(new Font(labelField_Title.getFont().getFontName(), Font.PLAIN, labelField_Title.getFont().getSize() + 10));
		panelField_Title.add(labelField_Title);
		
		JPanel panelField_1 = new JPanel();
		panelField_1.setLayout(new BorderLayout());
		JPanel panelField_1_Name = new JPanel();
		panelField_1_Name.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldLastName = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_LAST_NAME));
		this.labelLastName = new JLabel();
		this.labelLastName.setFont(new Font(this.labelLastName.getFont().getFontName(), Font.ITALIC, this.labelLastName.getFont().getSize()));		
		JLabel labelFieldFirstName = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_FIRST_NAME));
		this.labelFirstName = new JLabel();
		this.labelFirstName.setFont(new Font(this.labelLastName.getFont().getFontName(), Font.ITALIC, this.labelLastName.getFont().getSize()));
		panelField_1_Name.add(labelFieldLastName);
		panelField_1_Name.add(this.labelLastName);
		panelField_1_Name.add(labelFieldFirstName);
		panelField_1_Name.add(this.labelFirstName);
		this.buttonFriend = new JToggleButton();
		this.buttonFriend.setBackground(new Color(66, 139, 202));
		this.buttonFriend.setForeground(Color.WHITE);
		panelField_1.add(BorderLayout.WEST, panelField_1_Name);
		panelField_1.add(BorderLayout.EAST, this.buttonFriend);
		
		JPanel panelField_2 = new JPanel();
		panelField_2.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldAge = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_AGE));
		this.labelAge = new JLabel();
		this.labelAge.setFont(new Font(this.labelAge.getFont().getFontName(), Font.ITALIC, this.labelAge.getFont().getSize()));
		panelField_2.add(labelFieldAge);
		panelField_2.add(this.labelAge);
		
		JPanel panelField_3 = new JPanel();
		panelField_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldEmail = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_EMAIL));
		this.labelEmail = new JLabel();
		this.labelEmail.setFont(new Font(this.labelEmail.getFont().getFontName(), Font.ITALIC, this.labelEmail.getFont().getSize()));
		panelField_3.add(labelFieldEmail);
		panelField_3.add(this.labelEmail);
		
		JPanel panelField_4 = new JPanel();
		panelField_4.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldTown = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TOWN));
		this.labelTown = new JLabel();
		this.labelTown.setFont(new Font(this.labelTown.getFont().getFontName(), Font.ITALIC, this.labelTown.getFont().getSize()));		
		JLabel labelFieldAddress = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_ADDRESS));
		this.labelAddress = new JLabel();
		this.labelAddress.setFont(new Font(this.labelAddress.getFont().getFontName(), Font.ITALIC, this.labelAddress.getFont().getSize()));
		panelField_4.add(labelFieldTown);
		panelField_4.add(this.labelTown);
		panelField_4.add(labelFieldAddress);
		panelField_4.add(this.labelAddress);
		
		JPanel panelField_5 = new JPanel();
		panelField_5.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldPhoneNumber = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_PHONE_NUMBER));
		this.labelPhoneNumber = new JLabel();
		this.labelPhoneNumber.setFont(new Font(this.labelPhoneNumber.getFont().getFontName(), Font.ITALIC, this.labelPhoneNumber.getFont().getSize()));
		panelField_5.add(labelFieldPhoneNumber);
		panelField_5.add(this.labelPhoneNumber);
		
		JPanel panelField_6 = new JPanel();
		panelField_6.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelFieldTypeConduite = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TYPE_CONDUITE));
		this.labelTypeConduite = new JLabel();
		this.labelTypeConduite.setFont(new Font(this.labelTypeConduite.getFont().getFontName(), Font.ITALIC, this.labelTypeConduite.getFont().getSize()));		
		JLabel labelFieldTypeConducteur = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TYPE_CONDUCTEUR));
		this.labelTypeConducteur = new JLabel();
		this.labelTypeConducteur.setFont(new Font(this.labelTypeConducteur.getFont().getFontName(), Font.ITALIC, this.labelTypeConducteur.getFont().getSize()));
		panelField_6.add(labelFieldTypeConduite);
		panelField_6.add(this.labelTypeConduite);
		panelField_6.add(labelFieldTypeConducteur);
		panelField_6.add(this.labelTypeConducteur);
		panelField_6.setBorder(BorderFactory.createEmptyBorder(0,0,20,0));
		JSeparator separator = new JSeparator(JSeparator.HORIZONTAL);
		
		JPanel panelField_7 = new JPanel();
		panelField_7.setLayout(new BoxLayout(panelField_7, BoxLayout.Y_AXIS));
		JPanel panelField_7_Report = new JPanel();
		panelField_7_Report.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelField_Report = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_TITLE_REPORT));
		labelField_Report.setFont(new Font(labelField_Report.getFont().getFontName(), Font.PLAIN, labelField_Report.getFont().getSize() + 5));
		panelField_7_Report.add(labelField_Report);
		JPanel panelField_7_Conducteur = new JPanel();
		panelField_7_Conducteur.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelNbSignalementConducteur = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_REPORT_CONDUCTEUR));
		this.labelNbSignalementConducteur = new JLabel();
		this.labelNbSignalementConducteur.setFont(new Font(this.labelNbSignalementConducteur.getFont().getFontName(), Font.ITALIC, this.labelNbSignalementConducteur.getFont().getSize()));
		panelField_7_Conducteur.add(labelNbSignalementConducteur);
		panelField_7_Conducteur.add(this.labelNbSignalementConducteur);
		JPanel panelField_7_Passager = new JPanel();
		panelField_7_Passager.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelNbSignalementPassager = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIELD_REPORT_PASSAGER));
		this.labelNbSignalementPassager = new JLabel();
		this.labelNbSignalementPassager.setFont(new Font(this.labelNbSignalementPassager.getFont().getFontName(), Font.ITALIC, this.labelNbSignalementPassager.getFont().getSize()));
		panelField_7_Passager.add(labelNbSignalementPassager);
		panelField_7_Passager.add(this.labelNbSignalementPassager);
		panelField_7.add(panelField_7_Report);
		panelField_7.add(panelField_7_Conducteur);
		panelField_7.add(panelField_7_Passager);
		panelField_7.setBorder(BorderFactory.createEmptyBorder(20,0,40,0));
		
		JPanel panelField_Validate = new JPanel();
		panelField_Validate.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.buttonValidate = new JButton();
		this.buttonValidate.setBackground(new Color(255, 255, 255));
		panelField_Validate.add(this.buttonValidate);
		
		panelContainer.add(panelField_Title);
		panelContainer.add(panelField_1);
		panelContainer.add(panelField_2);
		panelContainer.add(panelField_3);
		panelContainer.add(panelField_4);
		panelContainer.add(panelField_5);
		panelContainer.add(panelField_6);
		panelContainer.add(separator);
		panelContainer.add(panelField_7);
		panelContainer.add(panelField_Validate);
		
		this.add(panelContainer);
	}
}
