package views;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.text.ParseException;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import internationalisation.Constantes;

public class ViewRegister extends JPanel {

	public JPanel panelImage;
	public JPanel panelError;
	public JPanel panelField;
	public JPanel panelName;
	public JPanel panelButton;
	public JLabel labelLastName;
	public JTextField tfLastName;
	public JLabel labelFirstName;
	public JTextField tfFirstName;
	public JLabel labelPhoneNumber;
	public JFormattedTextField ftfPhoneNumber;
	public JLabel labelUsername;
	public JTextField tfUsername;
	public JLabel labelEmail;
	public JTextField tfEmail;
	public JLabel labelPassword;
	public JPasswordField pfPassword;
	public JButton buttonRegister;
	public JLabel labelError;
	public JButton buttonCancel;
	
	public ViewRegister(){
		
		this.panelImage = new JPanel();
		this.panelError = new JPanel();
		this.panelField = new JPanel();
		this.panelName = new JPanel();
		this.panelButton = new JPanel();		
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.panelImage.setLayout(new FlowLayout());
		this.panelError.setLayout(new FlowLayout());
		this.panelField.setLayout(new BoxLayout(this.panelField, BoxLayout.Y_AXIS));
		this.panelName.setLayout(new GridLayout(2, 2));
		this.panelButton.setLayout(new FlowLayout());
		
		JLabel labelImage = new JLabel(new ImageIcon(this.getClass().getClassLoader().getResource("Images/logo_polycar.png")));
		this.panelImage.add(labelImage);
		this.panelImage.setBorder(BorderFactory.createEmptyBorder(40, 0, 0, 0));
		
		this.add(this.panelImage);
		
		this.labelError = new JLabel();
		this.labelError.setForeground(Color.RED);
		this.panelError.add(this.labelError);
		this.add(this.panelError);
		
		this.labelLastName = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_LAST_NAME));
		this.tfLastName = new JTextField(24);
		
		this.labelFirstName = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_FIRST_NAME));
		this.tfFirstName = new JTextField(24);
		
		this.panelName.add(this.labelLastName);
		this.panelName.add(this.labelFirstName);
		this.panelName.add(this.tfLastName);
		this.panelName.add(this.tfFirstName);
		
		this.add(this.panelName);
		
		this.labelPhoneNumber = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_PHONE_NUMBER));
		try {
			MaskFormatter formatter = new MaskFormatter("## ## ## ## ##");
			this.ftfPhoneNumber = new JFormattedTextField(formatter);
		} catch (ParseException e) {
			this.ftfPhoneNumber = new JFormattedTextField();
		}
		
		this.labelUsername = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_USERNAME));
		this.tfUsername = new JTextField();
		
		this.labelEmail = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_EMAIL));
		this.tfEmail = new JTextField();
		
		this.labelPassword = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_PASSWORD));
		this.pfPassword = new JPasswordField();
		
		this.buttonRegister = new JButton();
		this.buttonRegister.setBackground(new Color(66, 139, 202));
		this.buttonRegister.setForeground(Color.WHITE);
		this.buttonCancel = new JButton();
		this.buttonCancel.setBackground(new Color(224, 224, 224));
		
		this.panelField.add(this.labelPhoneNumber);
		this.panelField.add(this.ftfPhoneNumber);
		
		this.panelField.add(this.labelUsername);
		this.panelField.add(this.tfUsername);
		
		this.panelField.add(this.labelEmail);
		this.panelField.add(this.tfEmail);
		
		this.panelField.add(this.labelPassword);
		this.panelField.add(this.pfPassword);
		
		this.add(this.panelField);
		

		this.panelButton.add(this.buttonRegister);
		this.panelButton.add(this.buttonCancel);
		this.panelButton.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
		
		this.add(this.panelButton);
	}
}
