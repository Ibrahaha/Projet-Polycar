package views;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import internationalisation.Constantes;

public class ViewLogin extends JPanel {
		
	public JLabel labelUsername;
	public JTextField tfUsername;
	public JLabel labelPassword;
	public JPasswordField pfPassword;
	public JButton buttonLogin;
	public JButton buttonRegister;
	public JLabel labelError;
	
	public ViewLogin(){
		
		JPanel panelImage = new JPanel();
		JPanel panelError = new JPanel();
		JPanel panelField = new JPanel();
		JPanel panelButton = new JPanel();		
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		panelImage.setLayout(new FlowLayout());
		panelField.setLayout(new BoxLayout(panelField, BoxLayout.Y_AXIS));
		panelButton.setLayout(new FlowLayout());
		
		JLabel labelImage = new JLabel(new ImageIcon(this.getClass().getClassLoader().getResource("Images/logo_polycar.png")));
		panelImage.add(labelImage);
		panelImage.setBorder(BorderFactory.createEmptyBorder(40, 0, 0, 0));
		
		this.add(panelImage);		
		
		this.labelError = new JLabel();
		this.labelError.setForeground(Color.RED);
		panelError.add(this.labelError);
		this.add(panelError);
		
		this.labelUsername = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_USERNAME));
		this.tfUsername = new JTextField(50);
		
		this.labelPassword = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_PASSWORD));
		this.pfPassword = new JPasswordField(50);
		
		this.buttonLogin = new JButton();
		this.buttonLogin.setBackground(new Color(66, 139, 202));
		this.buttonLogin.setForeground(Color.WHITE);
		this.buttonRegister = new JButton();
		this.buttonRegister.setBackground(new Color(224, 224, 224));
		
		panelField.add(this.labelUsername);
		panelField.add(this.tfUsername);
		
		panelField.add(this.labelPassword);
		panelField.add(this.pfPassword);
		
		this.add(panelField);
		
		panelButton.add(this.buttonLogin);
		panelButton.add(this.buttonRegister);
		panelButton.setBorder(BorderFactory.createEmptyBorder(40, 0, 0, 0));
		
		this.add(panelButton);
	}
}
