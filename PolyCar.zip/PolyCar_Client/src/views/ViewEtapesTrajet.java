package views;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class ViewEtapesTrajet extends JPanel {

	public JLabel labelEtape;
	public JLabel labelHeure;
	
	public ViewEtapesTrajet(){
		
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		this.labelEtape = new JLabel();
		JLabel labelSeparateur = new JLabel(":");
		this.labelHeure = new JLabel();
		
		panelContainer.add(this.labelEtape);
		panelContainer.add(labelSeparateur);
		panelContainer.add(this.labelHeure);
		
		this.add(panelContainer);
	}
}
