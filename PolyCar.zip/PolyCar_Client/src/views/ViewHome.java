package views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;

import internationalisation.Constantes;

public class ViewHome extends JPanel {

	public JTextArea taNotifications;
	public JButton buttonClearNotification;
	public JButton buttonMyProfil;
	public JButton buttonAddTrajet;
	public JButton buttonFindTrajet;
	public JButton buttonDisconnect;
	public JComboBox<String> cbTrajets;
	public JButton buttonSelectTypeTrajet;
	public JLabel labelHelloName;
	public JPanel panelTrajets;
	
	public ViewHome(){
		
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new BorderLayout());
		
		JPanel panelTop = new JPanel();
		panelTop.setLayout(new FlowLayout(FlowLayout.LEFT));
		
		JPanel panelTopImage = new JPanel();
		JLabel labelImage = new JLabel(new ImageIcon(this.getClass().getClassLoader().getResource("Images/logo_polycar_small.png")));
		panelTopImage.add(labelImage);
		panelTopImage.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 150));
		panelTop.add(panelTopImage);
		
		JPanel panelTopButtons = new JPanel();
		panelTopButtons.setLayout(new GridLayout(1, 3));
		panelTopButtons.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 250));
		this.buttonMyProfil = new JButton();
		this.buttonMyProfil.setBackground(new Color(66, 139, 202));
		this.buttonMyProfil.setForeground(Color.WHITE);
		this.buttonAddTrajet = new JButton();
		this.buttonAddTrajet.setBackground(new Color(255, 255, 255));
		this.buttonFindTrajet = new JButton();
		this.buttonFindTrajet.setBackground(new Color(255, 255, 255));
		
		panelTopButtons.add(this.buttonAddTrajet);
		panelTopButtons.add(this.buttonMyProfil);
		panelTopButtons.add(this.buttonFindTrajet);
		
		this.buttonDisconnect = new JButton();
		this.buttonDisconnect.setBackground(new Color(66, 139, 202));
		this.buttonDisconnect.setForeground(Color.WHITE);
		
		panelTop.add(panelTopButtons);		
		panelTop.add(this.buttonDisconnect);
		
		JPanel panelMid = new JPanel();
		panelMid.setLayout(new BorderLayout());
		
		JPanel panelMidLeft = new JPanel();
		panelMidLeft.setLayout(new BoxLayout(panelMidLeft, BoxLayout.Y_AXIS));
		
		JPanel panelMidLeftHello = new JPanel();
		panelMidLeftHello.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelHello = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_HELLO));
		labelHello.setFont(new Font(labelHello.getFont().getFontName(), Font.PLAIN, 25));
		this.labelHelloName = new JLabel();
		this.labelHelloName.setFont(new Font(this.labelHelloName.getFont().getFontName(), Font.ITALIC, 25));
		panelMidLeftHello.add(labelHello);
		panelMidLeftHello.add(this.labelHelloName);
		JSeparator separator = new JSeparator(JSeparator.HORIZONTAL);
		JPanel panelMidLeftTrajet = new JPanel();
		panelMidLeftTrajet.setLayout(new FlowLayout());
		String[] items = {"Conducteur", "Passager"};
		this.cbTrajets = new JComboBox<>(items);
		this.cbTrajets.setBackground(new Color(255, 255, 255));
		this.buttonSelectTypeTrajet = new JButton();
		this.buttonSelectTypeTrajet.setBackground(new Color(255, 255, 255));
		panelMidLeftTrajet.add(this.cbTrajets);
		panelMidLeftTrajet.add(this.buttonSelectTypeTrajet);
		
		panelMidLeft.add(panelMidLeftHello);
		panelMidLeft.add(separator);
		panelMidLeft.add(panelMidLeftTrajet);
		
		
		JPanel panelMidRight = new JPanel();
		panelMidRight.setLayout(new FlowLayout());
		
		this.buttonClearNotification = new JButton();
		this.buttonClearNotification.setBackground(new Color(255, 255, 255));
		panelMidRight.add(this.buttonClearNotification);
		this.taNotifications = new JTextArea();
		this.taNotifications.setEditable(false);
		this.taNotifications.setBackground(null);
		JScrollPane scrollPaneNotifications = new JScrollPane(taNotifications);
		scrollPaneNotifications.setPreferredSize(new Dimension(500,100));
		panelMidRight.add(scrollPaneNotifications);
		
		panelMid.add(BorderLayout.WEST, panelMidLeft);
		panelMid.add(BorderLayout.EAST, panelMidRight);
		
		JPanel panelBot = new JPanel();
		this.panelTrajets = new JPanel();
		this.panelTrajets.setLayout(new BoxLayout(this.panelTrajets, BoxLayout.Y_AXIS));
		JScrollPane scrollPaneTrajets = new JScrollPane(this.panelTrajets);
		scrollPaneTrajets.setPreferredSize(new Dimension(1150, 250));
		
		panelBot.add(scrollPaneTrajets);
		
		panelContainer.add(BorderLayout.NORTH, panelTop);
		panelContainer.add(BorderLayout.CENTER, panelMid);
		panelContainer.add(BorderLayout.SOUTH, panelBot);
		
		this.add(panelContainer);
	}
}
