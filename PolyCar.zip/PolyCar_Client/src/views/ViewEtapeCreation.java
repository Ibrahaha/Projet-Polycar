package views;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ViewEtapeCreation extends JPanel {

	public JLabel labelEtape;
	public JLabel labelHeure;
	public JButton buttonRemove;
	
	public ViewEtapeCreation(){
		
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new FlowLayout());
		
		this.labelEtape = new JLabel();
		this.labelHeure = new JLabel();
		this.buttonRemove = new JButton();
		this.buttonRemove.setBackground(new Color(255, 255, 255));
		panelContainer.add(this.labelEtape);
		panelContainer.add(this.labelHeure);
		panelContainer.add(this.buttonRemove);
		
		this.add(panelContainer);
	}
}
