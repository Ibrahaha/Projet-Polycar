package views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;

import internationalisation.Constantes;

public class ViewTrajet extends JPanel {
	
	public JLabel labelDate;
	public JLabel labelVilleDepart;
	public JLabel labelVilleArrivee;
	public JLabel labelHeureDepart;
	public JLabel labelHeureArrivee;
	public JPanel panelEtapes;
	public JLabel labelNbPassagers;
	public JPanel panelPassagers;
	public JLabel labelPrix;
	public JLabel labelTypePrix;
	public JLabel labelVehicule;
	public JPanel panelButtons;
	public JButton buttonUnregisterCancel;
	public JButton buttonReport;
	public JButton buttonRemove;
	
	public ViewTrajet(){
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new FlowLayout());	
		
		JPanel panelHoraire = new JPanel();
		panelHoraire.setLayout(new BoxLayout(panelHoraire, BoxLayout.Y_AXIS));
		JPanel panelDate = new JPanel();
		panelDate.setLayout(new FlowLayout(FlowLayout.LEFT));
		this.labelDate = new JLabel();
		this.labelDate.setFont(new Font(this.labelDate.getFont().getFontName(), Font.ITALIC, this.labelDate.getFont().getSize()));
		panelDate.add(this.labelDate);
		JSeparator separator_1 = new JSeparator(JSeparator.HORIZONTAL);	
		panelHoraire.add(panelDate);
		panelHoraire.add(separator_1);
		
		JPanel panelDepart = new JPanel();
		panelDepart.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelDepart = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_START));
		this.labelHeureDepart = new JLabel();
		this.labelHeureDepart.setFont(new Font(this.labelHeureDepart.getFont().getFontName(), Font.ITALIC, this.labelHeureDepart.getFont().getSize()));
		JLabel labelLinkDateStart = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_LINK_DATE_START));
		this.labelVilleDepart = new JLabel();
		this.labelVilleDepart.setFont(new Font(this.labelVilleDepart.getFont().getFontName(), Font.ITALIC, this.labelVilleDepart.getFont().getSize()));
		panelDepart.add(labelDepart);
		panelDepart.add(this.labelHeureDepart);
		panelDepart.add(labelLinkDateStart);
		panelDepart.add(this.labelVilleDepart);
		panelHoraire.add(panelDepart);
		
		JPanel panelArrivee = new JPanel();
		panelArrivee.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelArrivee = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_END));
		this.labelHeureArrivee = new JLabel();
		this.labelHeureArrivee.setFont(new Font(this.labelHeureArrivee.getFont().getFontName(), Font.ITALIC, this.labelHeureArrivee.getFont().getSize()));
		JLabel labelLinkDateArrivee = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_LINK_DATE_END));
		this.labelVilleArrivee = new JLabel();
		this.labelVilleArrivee.setFont(new Font(this.labelVilleArrivee.getFont().getFontName(), Font.ITALIC, this.labelVilleArrivee.getFont().getSize()));
		panelArrivee.add(labelArrivee);
		panelArrivee.add(this.labelHeureArrivee);
		panelArrivee.add(labelLinkDateArrivee);
		panelArrivee.add(this.labelVilleArrivee);
		panelHoraire.add(panelArrivee);
		
		panelContainer.add(panelHoraire);
		
		JPanel panelContainerEtape = new JPanel();
		panelContainerEtape.setLayout(new BoxLayout(panelContainerEtape, BoxLayout.Y_AXIS));
		JPanel panelTitleEtape = new JPanel();
		panelTitleEtape.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelEtape = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_STEP));
		panelTitleEtape.add(labelEtape);
		JSeparator separator_2 = new JSeparator(JSeparator.HORIZONTAL);	
		this.panelEtapes = new JPanel();
		this.panelEtapes.setLayout(new BoxLayout(this.panelEtapes, BoxLayout.Y_AXIS));
		JScrollPane scrollPaneEtape = new JScrollPane(this.panelEtapes);
		scrollPaneEtape.setPreferredSize(new Dimension(150, 60));
		panelContainerEtape.add(panelTitleEtape);
		panelContainerEtape.add(separator_2);
		panelContainerEtape.add(scrollPaneEtape);
		panelContainer.add(panelContainerEtape);
		
		JPanel panelPassager = new JPanel();
		panelPassager.setLayout(new BoxLayout(panelPassager, BoxLayout.Y_AXIS));
		
		JPanel panelNbPassager = new JPanel();
		panelNbPassager.setLayout(new FlowLayout(FlowLayout.LEFT));	
		JLabel labelPassagers = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_PASSENGERS));
		labelPassagers.setFont(new Font(labelPassagers.getFont().getFontName(), Font.ITALIC, labelPassagers.getFont().getSize()));
		this.labelNbPassagers = new JLabel();
		this.labelNbPassagers.setFont(new Font(this.labelNbPassagers.getFont().getFontName(), Font.ITALIC, this.labelNbPassagers.getFont().getSize()));
		panelNbPassager.add(labelPassagers);
		panelNbPassager.add(this.labelNbPassagers);
		JSeparator separator_3 = new JSeparator(JSeparator.HORIZONTAL);	
		
		panelPassager.add(panelNbPassager);
		panelPassager.add(separator_3);
				
		this.panelPassagers = new JPanel();
		this.panelPassagers.setLayout(new BoxLayout(this.panelPassagers, BoxLayout.Y_AXIS));
		JScrollPane scrollPanePassager = new JScrollPane(this.panelPassagers);
		scrollPanePassager.setPreferredSize(new Dimension(350, 60));

		panelPassager.add(scrollPanePassager);
		
		panelContainer.add(panelPassager);
		
		JPanel panelAdditionnalInformations = new JPanel();
		panelAdditionnalInformations.setLayout(new BoxLayout(panelAdditionnalInformations, BoxLayout.Y_AXIS));
		
		JPanel panelTitleInformation = new JPanel();
		panelTitleInformation.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelAdditionnalInformations = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_ADDITIONNAL_INFORMATIONS));
		JSeparator separator_4 = new JSeparator(JSeparator.HORIZONTAL);	
		panelTitleInformation.add(labelAdditionnalInformations);
		panelAdditionnalInformations.add(panelTitleInformation);
		panelAdditionnalInformations.add(separator_4);
		
		JPanel panelPrice = new JPanel();
		panelPrice.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelTextPrice = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TEXT_PRICE));
		this.labelPrix = new JLabel();
		this.labelPrix.setFont(new Font(this.labelPrix.getFont().getFontName(), Font.ITALIC, this.labelPrix.getFont().getSize()));
		JLabel labelPerPassenger = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_PER_PASSENGER));
		this.labelTypePrix = new JLabel();
		this.labelTypePrix.setFont(new Font(this.labelTypePrix.getFont().getFontName(), Font.ITALIC, this.labelTypePrix.getFont().getSize()));
		panelPrice.add(labelTextPrice);
		panelPrice.add(this.labelPrix);
		panelPrice.add(labelPerPassenger);
		panelPrice.add(this.labelTypePrix);
		
		panelAdditionnalInformations.add(panelPrice);
		
		JPanel panelVehicule = new JPanel();
		panelVehicule.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelTextVehicule = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TEXT_CONDUITE));
		this.labelVehicule = new JLabel();
		this.labelVehicule.setFont(new Font(this.labelTypePrix.getFont().getFontName(), Font.ITALIC, this.labelTypePrix.getFont().getSize()));
		panelVehicule.add(labelTextVehicule);
		panelVehicule.add(this.labelVehicule);
		panelAdditionnalInformations.add(panelVehicule);
		
		panelContainer.add(panelAdditionnalInformations);
		
		this.panelButtons = new JPanel();
		this.panelButtons.setLayout(new FlowLayout());
		this.buttonUnregisterCancel = new JButton();
		this.buttonUnregisterCancel.setVisible(true);
		this.buttonUnregisterCancel.setBackground(new Color(66, 139, 202));
		this.buttonUnregisterCancel.setForeground(Color.WHITE);
		this.buttonReport = new JButton();
		this.buttonReport.setVisible(false);
		this.buttonReport.setBackground(new Color(255, 255, 255));
		this.buttonRemove = new JButton();
		this.buttonRemove.setVisible(false);
		this.buttonRemove.setBackground(new Color(66, 139, 202));
		this.buttonRemove.setForeground(Color.WHITE);
		this.panelButtons.add(this.buttonUnregisterCancel);
		this.panelButtons.add(this.buttonReport);		
		this.panelButtons.add(this.buttonRemove);
		
		panelContainer.add(this.panelButtons);
		
		this.add(panelContainer);
		this.setBorder(BorderFactory.createEtchedBorder());
	}

}
