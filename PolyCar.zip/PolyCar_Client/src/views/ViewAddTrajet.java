package views;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.text.ParseException;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.text.MaskFormatter;

import internationalisation.Constantes;

public class ViewAddTrajet extends JPanel {
	
	public JTextField tfVilleDepart;
	public JTextField tfVilleArrivee;
	public JFormattedTextField ftfHeureDepart;
	public JFormattedTextField ftfHeureArrivee;
	public JFormattedTextField ftfDate;
	public JTextField tfEtapeNom;
	public JFormattedTextField tfEtapeHeure;
	public JPanel panelEtapes;
	public JSpinner spinnerNbPassagers;
	public JSpinner spinnerPrix;
	public JComboBox<String> cbTypePrix;
	public JComboBox<String> cbTypeVehicule;
	public JButton buttonAddEtape;
	public JButton buttonConfirm;
	public JButton buttonCancel;
	public JLabel labelError;

	
	public ViewAddTrajet(){
		
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new BoxLayout(panelContainer, BoxLayout.Y_AXIS));
		
		JPanel panelFieldError = new JPanel();		
		panelFieldError.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.labelError = new JLabel();
		this.labelError.setForeground(Color.RED);
		panelFieldError.add(this.labelError);
		
		JPanel panelFieldDate = new JPanel();		
		panelFieldDate.setLayout(new BoxLayout(panelFieldDate, BoxLayout.Y_AXIS));
		
		JPanel panelFieldDate_1 = new JPanel();
		panelFieldDate_1.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelTitleDepart = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TOWN_DEPART));
		panelFieldDate_1.add(labelTitleDepart);
		
		JPanel panelFieldDate_2 = new JPanel();
		panelFieldDate_2.setLayout(new FlowLayout(FlowLayout.LEFT));
		this.tfVilleDepart = new JTextField(10);
		try {
			MaskFormatter formatter = new MaskFormatter("##:##");
			this.ftfHeureDepart = new JFormattedTextField(formatter);
		} catch (ParseException e) {
			this.ftfHeureDepart = new JFormattedTextField();
		}
		this.ftfHeureDepart.setPreferredSize(new Dimension(50,20));
		try {
			MaskFormatter formatter = new MaskFormatter("##/##/####");
			this.ftfDate = new JFormattedTextField(formatter);
		} catch (ParseException e) {
			this.ftfDate = new JFormattedTextField();
		}
		this.ftfDate.setPreferredSize(new Dimension(70,20));
		panelFieldDate_2.add(this.tfVilleDepart);
		panelFieldDate_2.add(this.ftfHeureDepart);
		panelFieldDate_2.add(this.ftfDate);
		
		JPanel panelFieldDate_3 = new JPanel();
		panelFieldDate_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelTitleArrivee = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TOWN_ARRIVEE));
		panelFieldDate_3.add(labelTitleArrivee);
		
		JPanel panelFieldDate_4 = new JPanel();
		panelFieldDate_4.setLayout(new FlowLayout(FlowLayout.LEFT));
		this.tfVilleArrivee = new JTextField(10);
		try {
			MaskFormatter formatter = new MaskFormatter("##:##");
			this.ftfHeureArrivee = new JFormattedTextField(formatter);
		} catch (ParseException e) {
			this.ftfHeureArrivee = new JFormattedTextField();
		}
		this.ftfHeureArrivee.setPreferredSize(new Dimension(50,20));
		panelFieldDate_4.add(this.tfVilleArrivee);
		panelFieldDate_4.add(this.ftfHeureArrivee);
		
		panelFieldDate.add(panelFieldDate_1);
		JSeparator separator_1 = new JSeparator(JSeparator.HORIZONTAL);
		panelFieldDate.add(separator_1);
		panelFieldDate.add(panelFieldDate_2);
		panelFieldDate.add(panelFieldDate_3);
		JSeparator separator_2 = new JSeparator(JSeparator.HORIZONTAL);
		panelFieldDate.add(separator_2);
		panelFieldDate.add(panelFieldDate_4);
		
		JPanel panelFieldEtape = new JPanel();
		panelFieldEtape.setLayout(new BoxLayout(panelFieldEtape, BoxLayout.Y_AXIS));
		
		JPanel panelFieldEtape_1 = new JPanel();
		panelFieldEtape_1.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelTitleEtape = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_STEP));
		JLabel labelEtapeName = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TOWN) + " :");
		this.tfEtapeNom = new JTextField(5);
		JLabel labelEtapeHour = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_HOUR) + " :");
		try {
			MaskFormatter formatter = new MaskFormatter("##:##");
			this.tfEtapeHeure = new JFormattedTextField(formatter);
		} catch (ParseException e) {
			this.tfEtapeHeure = new JFormattedTextField();
		}
		this.tfEtapeHeure.setPreferredSize(new Dimension(50,20));
		this.buttonAddEtape = new JButton();
		this.buttonAddEtape.setBackground(new Color(255, 255, 255));
		panelFieldEtape_1.add(labelTitleEtape);
		panelFieldEtape_1.add(labelEtapeName);
		panelFieldEtape_1.add(this.tfEtapeNom);
		panelFieldEtape_1.add(labelEtapeHour);
		panelFieldEtape_1.add(this.tfEtapeHeure);
		panelFieldEtape_1.add(this.buttonAddEtape);
		
		JPanel panelFieldEtape_2 = new JPanel();
		panelFieldEtape_2.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.panelEtapes = new JPanel();
		this.panelEtapes.setLayout(new BoxLayout(this.panelEtapes, BoxLayout.Y_AXIS));
		JScrollPane scrollEtape = new JScrollPane(this.panelEtapes);
		scrollEtape.setPreferredSize(new Dimension(300, 150));
		panelFieldEtape_2.add(scrollEtape);
		
		panelFieldEtape.add(panelFieldEtape_1);
		JSeparator separator_3 = new JSeparator(JSeparator.HORIZONTAL);
		panelFieldEtape.add(separator_3);
		panelFieldEtape.add(panelFieldEtape_2);
		
		JPanel panelBot = new JPanel();
		panelBot.setLayout(new FlowLayout());
		
		JPanel panelAdditionnalInformations = new JPanel();
		panelAdditionnalInformations.setLayout(new BoxLayout(panelAdditionnalInformations, BoxLayout.Y_AXIS));
		
		JPanel panelAdditionnalInformations_1 = new JPanel();
		panelAdditionnalInformations_1.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel panelTitleAddInfo = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_ADDITIONNAL_INFORMATIONS));
		panelAdditionnalInformations_1.add(panelTitleAddInfo);
		
		JPanel panelAdditionnalInformations_2 = new JPanel();
		panelAdditionnalInformations_2.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelNbPassagers = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_NUMBER_PASSENGERS));
		SpinnerNumberModel spinnerModel_passager = new SpinnerNumberModel(0, 0, 99, 1);
		this.spinnerNbPassagers = new JSpinner(spinnerModel_passager);
		panelAdditionnalInformations_2.add(labelNbPassagers);
		panelAdditionnalInformations_2.add(this.spinnerNbPassagers);
		
		JPanel panelAdditionnalInformations_3 = new JPanel();
		panelAdditionnalInformations_3.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelPrix = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TEXT_PRICE));
		SpinnerNumberModel spinnerModel_prix = new SpinnerNumberModel(0, 0, 99, 1);
		this.spinnerPrix = new JSpinner(spinnerModel_prix);
		JLabel labelPrix_liaison = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_TEXT_PRICE_LINK));
		String[] items_prix = {"Voyage", "Segment"};
		this.cbTypePrix = new JComboBox<String>(items_prix);
		this.cbTypePrix.setBackground(new Color(255, 255, 255));
		panelAdditionnalInformations_3.add(labelPrix);
		panelAdditionnalInformations_3.add(this.spinnerPrix);
		panelAdditionnalInformations_3.add(labelPrix_liaison);
		panelAdditionnalInformations_3.add(this.cbTypePrix);
		
		JPanel panelAdditionnalInformations_4 = new JPanel();
		panelAdditionnalInformations_4.setLayout(new FlowLayout(FlowLayout.LEFT));
		JLabel labelVehicule = new JLabel(Constantes.resourceBundle.getString(Constantes.LABEL_VEHICULE));
		String[] items_vehicule = {"Voiture r�cente", "Camion", "Voiture en fin de vie"};
		this.cbTypeVehicule = new JComboBox<String>(items_vehicule);
		this.cbTypeVehicule.setBackground(new Color(255, 255, 255));
		panelAdditionnalInformations_4.add(labelVehicule);
		panelAdditionnalInformations_4.add(this.cbTypeVehicule);
		
		panelAdditionnalInformations.add(panelAdditionnalInformations_1);
		JSeparator separator_4 = new JSeparator(JSeparator.HORIZONTAL);
		panelAdditionnalInformations.add(separator_4);
		panelAdditionnalInformations.add(panelAdditionnalInformations_2);
		panelAdditionnalInformations.add(panelAdditionnalInformations_3);
		panelAdditionnalInformations.add(panelAdditionnalInformations_4);
		
		JPanel panelButton = new JPanel();
		panelButton.setLayout(new GridLayout(2, 1));
		this.buttonConfirm = new JButton();
		this.buttonConfirm.setBackground(new Color(66, 139, 202));
		this.buttonConfirm.setForeground(Color.WHITE);
		this.buttonCancel = new JButton();
		this.buttonCancel.setBackground(new Color(255, 255, 255));
		panelButton.add(this.buttonConfirm);
		panelButton.add(this.buttonCancel);
		
		panelBot.add(panelAdditionnalInformations);
		panelBot.add(panelButton);
		
		panelContainer.add(panelFieldError);
		panelContainer.add(panelFieldDate);
		panelContainer.add(panelFieldEtape);
		panelContainer.add(panelBot);
		
		this.add(panelContainer);
		
	}

}
