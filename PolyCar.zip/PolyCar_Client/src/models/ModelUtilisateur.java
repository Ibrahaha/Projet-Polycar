package models;

import java.util.Observable;

public class ModelUtilisateur extends Observable {

	Utilisateur utilisateur;
	
	public ModelUtilisateur(){
		
		this.utilisateur = null;
	}	
	
	public ModelUtilisateur(Utilisateur utilisateur){
		
		this.utilisateur = utilisateur;
	}
	
	public void setUtilisateur(Utilisateur utilisateur){
		
		this.utilisateur = utilisateur;
		this.setChanged();
		this.notifyObservers();
	}
	
	public String getName(){
		return utilisateur.firstName;
	}
	
	public Utilisateur getUser(){
		return this.utilisateur;
	}
	
	public void init(){
		this.setChanged();
		this.notifyObservers();
	}
}
