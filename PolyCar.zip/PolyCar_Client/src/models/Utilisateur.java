package models;

import java.util.ArrayList;
import java.util.List;

public class Utilisateur {

	String username;
	String password;
	String lastName;
	String firstName;
	String phoneNumber;
	String email;
	int age;
	String town;
	String address;
	String typeConducteur;
	String typeConduite;
	int nbSignalementConducteur;
	int nbSignalementPassager;
	List<Utilisateur> listeAmis;

	
	public Utilisateur(String username, String password, String lastName, String firstName, String phoneNumber, String email) {
		this.username = username;
		this.password = password;
		this.lastName = lastName;
		this.firstName = firstName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.age = 0;
		this.town = "";
		this.address = "";
		this.typeConducteur = "";
		this.typeConduite = "";
		this.nbSignalementConducteur = 0;
		this.nbSignalementPassager = 0;
		this.listeAmis = new ArrayList<Utilisateur>();
	}

	public Utilisateur(String username, String password, String lastName, String firstName, String phoneNumber, String email, int age,
			String town, String address, String typeConducteur, String typeConduite) {
		this.username = username;
		this.password = password;
		this.lastName = lastName;
		this.firstName = firstName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.age = age;
		this.town = town;
		this.address = address;
		this.typeConducteur = typeConducteur;
		this.typeConduite = typeConduite;
		this.nbSignalementConducteur = 0;
		this.nbSignalementPassager = 0;
		this.listeAmis = new ArrayList<Utilisateur>();
	}

	public Utilisateur(String username, String password, String lastName, String firstName, String phoneNumber,
			String email, int age, String town, String address, String typeConducteur, String typeConduite,
			int nbSignalementConducteur, int nbSignalementPassager, List<Utilisateur> listeAmis) {
		this.username = username;
		this.password = password;
		this.lastName = lastName;
		this.firstName = firstName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.age = age;
		this.town = town;
		this.address = address;
		this.typeConducteur = typeConducteur;
		this.typeConduite = typeConduite;
		this.nbSignalementConducteur = nbSignalementConducteur;
		this.nbSignalementPassager = nbSignalementPassager;
		this.listeAmis = listeAmis;
	}
	
	
	public String getNomPrenom(){
		return this.firstName.substring(0, 1).toUpperCase() + this.firstName.substring(1) + " " + this.lastName.toUpperCase();
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public int getAge() {
		return age;
	}

	public String getTown() {
		return town;
	}

	
	public String getAddress() {
		return address;
	}

	public String getTypeConducteur() {
		return typeConducteur;
	}

	public String getTypeConduite() {
		return typeConduite;
	}

	public int getNbSignalementConducteur() {
		return nbSignalementConducteur;
	}

	public int getNbSignalementPassager() {
		return nbSignalementPassager;
	}
	
	public List<Utilisateur> getListeAmis() {
		return listeAmis;
	}
	
	public boolean isFriend(Utilisateur friend){
		for(Utilisateur user: this.listeAmis){
			if(user.username.equals(friend.username)){
				return true;
			}
		}
		return false;
	}
}
