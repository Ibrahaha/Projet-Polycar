package models;

public class Notification {
	
	int id;
	String notification;
	String usernameDestinataire;
	
	public Notification(int id, String notification, String usernameDestinataire) {
		this.id = id;
		this.notification = notification;
		this.usernameDestinataire = usernameDestinataire;
	}
	
	public String getText(){
		return this.notification;
	}
}
