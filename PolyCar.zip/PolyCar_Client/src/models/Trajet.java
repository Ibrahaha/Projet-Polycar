package models;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Trajet {

	public int id;
	public String villeDepart;
	public String villeArrivee;
	public Calendar dateDepart;
	public Calendar dateArrivee;
	public List<Etape> etapes;
	public int nbPassagers;
	public int prix;
	public String typeVehicule;
	public String choixPaiement;
	public Utilisateur conducteur;
	public List<Utilisateur> listePassagers;

	public Trajet(String villeDepart, String villeArrivee, Calendar dateDepart, Calendar dateArrivee, int nbPassagers,
			int prix, String typeVehicule, String choixPaiement, Utilisateur conducteur, List<Etape> etapes) {
		this.id = -1;
		this.villeDepart = villeDepart;
		this.villeArrivee = villeArrivee;
		this.dateDepart = dateDepart;
		this.dateArrivee = dateArrivee;
		this.nbPassagers = nbPassagers;
		this.prix = prix;
		this.typeVehicule = typeVehicule;
		this.choixPaiement = choixPaiement;
		this.conducteur = conducteur;
		this.etapes = etapes;
		this.listePassagers = new ArrayList<Utilisateur>();
	}

	public Trajet(int id, String villeDepart, String villeArrivee, Calendar dateDepart, Calendar dateArrivee,
			List<Etape> etapes, int nbPassagers, int prix, String typeVehicule, String choixPaiement,
			Utilisateur conducteur, List<Utilisateur> listePassagers) {
		this.id = id;
		this.villeDepart = villeDepart;
		this.villeArrivee = villeArrivee;
		this.dateDepart = dateDepart;
		this.dateArrivee = dateArrivee;
		this.etapes = etapes;
		this.nbPassagers = nbPassagers;
		this.prix = prix;
		this.typeVehicule = typeVehicule;
		this.choixPaiement = choixPaiement;
		this.conducteur = conducteur;
		this.listePassagers = listePassagers;
	}
}
