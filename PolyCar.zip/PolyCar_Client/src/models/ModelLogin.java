package models;

import java.util.Observable;

public class ModelLogin extends Observable {

	boolean login;
	
	public ModelLogin(){
		this.login = false;
	}
	
	void setChanged(boolean bool){
		
		if(this.login != bool){
			this.login = bool;
			this.setChanged();
		}
		this.notifyObservers();		
	}
	
	public void setFalse(){
		setChanged(false);
	}
	
	public void setTrue(){
		setChanged(true);
	}
	
	public boolean getState(){
		return this.login;
	}
}
