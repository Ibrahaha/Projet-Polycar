package models;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Etape {

	String ville;
	Calendar date;
	
	public Etape(String ville, Calendar date){
		this.ville = ville;
		this.date = date;
	}
	
	public String getVille(){
		return this.ville;
	}
	
	public String getStringDate(){
		SimpleDateFormat heureFormatter = new SimpleDateFormat("h");
		SimpleDateFormat minuteFormatter = new SimpleDateFormat("mm");
		String heure = heureFormatter.format(this.date.getTime()) + "h" + minuteFormatter.format(this.date.getTime());
		return heure;
	}
	
	public Calendar getDate(){
		return this.date;
	}
}
