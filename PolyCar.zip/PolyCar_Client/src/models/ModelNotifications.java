package models;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

public class ModelNotifications extends Observable {

	List<Notification> notifications;
	
	public ModelNotifications(){
		this.notifications = new ArrayList<>();
	}

	public void setNotification(List<Notification> notifications){
		this.notifications = notifications;
		this.setChanged();
		this.notifyObservers();
	}
		
	public List<Notification> getNotifications(){
		return this.notifications;
	}
	
	public boolean isEmpty(){
		return this.notifications.isEmpty();
	}
}
