package models;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

public class ModelEtapes extends Observable {

	List<Etape> listeEtapes;
	
	public ModelEtapes(){
		this.listeEtapes = new ArrayList<Etape>();
	}
	
	public void addEtape(Etape etape){
		this.listeEtapes.add(etape);
		this.setChanged();
		this.notifyObservers();
	}
	
	public void removeEtape(int index){
		this.listeEtapes.remove(index);
		this.setChanged();
		this.notifyObservers();
	}
	
	public List<Etape> getListEtape(){
		return this.listeEtapes;
	}
}
