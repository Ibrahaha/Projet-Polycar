package models;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

public class ModelTrajets extends Observable {
	
	List<Trajet> trajets;
	
	public ModelTrajets(){
		this.trajets = new ArrayList<>();
	}

	public List<Trajet> getTrajets(){		
		return trajets;
	}
	
	public void setTrajets(List<Trajet> trajets){
		this.trajets.clear();
		this.trajets = trajets;
		this.setChanged();
		this.notifyObservers();	
	}
}
