package network;

import java.util.Calendar;
import java.util.List;

import models.Notification;
import models.Trajet;
import models.Utilisateur;


public interface InterfaceNetworkClient {

	/**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour v�rifier la concordance entre l�identifiant et le mot de passe, et r�cup�re la r�ponse du serveur contenant les informations sur l�utilisateur, sur ses trajets et ses notifications pour mettre � jour les mod�les correspondant.
     * @param username le nom d'utilisateur
     * @param password le mot de passe de l'utilisateur
     * @throws LoginException Exception pour indiquer que l�identifiant ou le mot de passe est incorrect
     */
    void login(String username, String password) throws LoginException;
    
    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour cr�er un compte utilisateur, et r�cup�re la r�ponse du serveur indiquant si c�est bien pass� ou non.
     * @param user Objet Utilisateur contenant toutes les informations li�es � un utilisateur
     * @throws RegisterException Exception pour indiquer que l�identifiant utilis� par l�utilisateur est d�j� utilis�
     */
    void register(Utilisateur user) throws RegisterException;

    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour r�cup�rer tous les trajets o� l�utilisateur est conducteur, et r�cup�re la r�ponse du serveur contenant la liste des trajets pour mettre � jour le mod�le correspondant.
     * @param user Objet Utilisateur contenant toutes les informations li�es � un utilisateur
     */
    void getTrajetsConducteur(Utilisateur user);
    
    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour r�cup�rer tous les trajets o� l�utilisateur est passager, et r�cup�re la r�ponse du serveur contenant les trajets pour mettre � jour le mod�le correspondant.
     * @param user Objet Utilisateur contenant toutes les informations li�es � un utilisateur
     */
    void getTrajetsPassager(Utilisateur user);
    
    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour effacer un vieux trajet, et r�cup�re la r�ponse du serveur contenant les trajets pour mettre � jour le mod�le correspondant.
     * @param trajet Objet Trajet que l�on veut supprimer
     */
    void removeTrajet(Trajet trajet);
    
    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour proposer un trajet, et r�cup�re la r�ponse du serveur contenant les trajets pour mettre � jour le mod�le correspondant.
     * @param trajet Objet Trajet que l�on veut ajouter
     */
    void addTrajet(Trajet trajet);
    
    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour r�cup�rer trouver des trajets, et r�cup�re la r�ponse du serveur contenant les trajets pour mettre � jour le mod�le correspondant.
     * @param villeDep String indiquant la ville de d�part pour les trajets � rechercher
     * @param villeArr String indiquant la ville de arriv�e pour les trajets � rechercher
     * @param date Calendar indiquant la date pour les trajets � rechercher
     */
    void findTrajet(Utilisateur user, String villeDep, String villeArr, Calendar date);
    
    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour annuler un trajet, et r�cup�re la r�ponse du serveur contenant les trajets pour mettre � jour le mod�le correspondant.
     * @param trajet Objet Trajet que l�on veut supprimer
     */
    void cancelTrajet(Trajet trajet);
    
    /**
     * G�n�re le JSON contenant les informations pour la requ�te qui sera transmise au serveur pour r�cup�rer les notifications concernant un utilisateur, et r�cup�re la r�ponse du serveur contenant une liste de notifications.
     * @param user Objet Utilisateur contenant toutes les informations li�es � un utilisateur
     */
    void getNotifications(Utilisateur user);
    
    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour supprimer les notications de l'utilisateur qu'il a vu, et r�cup�re la r�ponse du serveur contenant la liste des autres notifications de l�utilisateur pour mettre � jour le mod�le correspondant
     * @param notifications Liste de Notification contenant les notifications � supprimer
     */
    void deleteNotifications(List<Notification> notifications);
    
    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour signaler un utilisateur qui a �t� absent en tant que passager, et r�cup�re la r�ponse du serveur contenant les informations sur l�utilisateur qui a �t� signal� pour mettre � jour le mod�le correspondant
     * @param user Objet Utilisateur contenant toutes les informations li�es � l�utilisateur courant
     */
    void reportUserPassager(Utilisateur user);
    
    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour signaler un utilisateur qui a �t� absent en tant que conducteur, et r�cup�re la r�ponse du serveur contenant les informations sur l�utilisateur qui a �t� signal� pour mettre � jour le mod�le correspondant
     * @param user  Objet Utilisateur contenant toutes les informations li�es � l�utilisateur courant
     */
    void reportUserConducteur(Utilisateur user);
    
    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour d�sinscrire un utilisateur d�un trajet, et r�cup�re la r�ponse du serveur contenant la liste des trajets de l�utilisateur pour mettre � jour le mod�le correspondant
     * @param trajet Objet Trajet dont l�utilisateur veut se d�sinscrire
     * @param user Objet Utilisateur contenant toutes les informations li�es � un utilisateur
     */
    void unregisterTrajet(Trajet trajet, Utilisateur user);
    
    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour ajouter mettre � jour un utilisateur, et r�cup�re la r�ponse du serveur contenant les informations sur l�utilisateur qui a �t� mis � jour pour mettre � jour le mod�le correspondant
     * @param user Objet Utilisateur contenant toutes les informations li�es � l�utilisateur courant
     */
    void updateUtilisateur(Utilisateur user);
    
    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour ajouter un utilisateur des amis d�un autre utilisateur, et r�cup�re la r�ponse du serveur contenant les informations sur l�utilisateur ami pour mettre � jour le mod�le correspondant
     * @param myUser Objet Utilisateur contenant toutes les informations li�es � l�utilisateur courant
     * @param friendUser Objet Utilisateur contenant toutes les informations li�es � l�utilisateur que l�on souhaite ajouter comme ami
     */
    void addFriend(Utilisateur myUser, Utilisateur friendUser);
    
    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour retirer un utilisateur des amis d�un autre utilisateur, et r�cup�re la r�ponse du serveur contenant les informations sur l�utilisateur anciennement ami pour mettre � jour le mod�le correspondant
     * @param myUser Objet Utilisateur contenant toutes les informations li�es � l�utilisateur courant
     * @param friendUser  Objet Utilisateur contenant toutes les informations li�es � l�utilisateur que l�on souhaite retirer de ses amis
     */
    void removeFriend(Utilisateur myUser, Utilisateur friendUser);

    /**
     * G�n�re le JSON contenant les informations sur la requ�te qui sera transmise au serveur pour obtenir le profil d�un utilisateur, et r�cup�re la r�ponse du serveur contenant les informations sur l�utilisateur recherch� pour mettre � jour le mod�le correspondant
     * @param user Objet Utilisateur contenant toutes les informations li�es � l�utilisateur
     */
	void getProfile(Utilisateur user);
	
	/**
	 * G�n�re le JSON contenant les informations le trajet auquel l'utilisateur veut s'inscrire, et r�cup�re la r�ponse du serveur contenant les informations sur les trajets de l'utilisateur pour mettre � jour le mod�le correspondant
	 * @param user Objet Utilisateur contenant toutes les informations li�es � l�utilisateur courant
	 * @param trajet Objet Trajet dont l�utilisateur veut s'inscrire
	 */
	void registerTrajet(Utilisateur user, Trajet trajet);
}