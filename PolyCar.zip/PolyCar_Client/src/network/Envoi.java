package network;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.Callable;

import com.google.gson.Gson;



public class Envoi implements Callable<Message> {
	Socket connexionCliente;
	PrintWriter output;
	BufferedInputStream input;
	Message message;
	public Envoi(Message message) {
		try {
			this.connexionCliente = new Socket("127.0.0.1", 4444);
			this.message = message;
			this.output = new PrintWriter(this.connexionCliente.getOutputStream());
			this.input = new BufferedInputStream(this.connexionCliente.getInputStream());
		} catch(UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	@Override
	public Message call()  throws NoConnectionExecption{
		Gson gson = new Gson();
		this.output.write(gson.toJson(message));
		this.output.flush();
		String input2;
		try {
			input2 = read();
			Message toreceve = gson.fromJson(input2,Message.class);
			if(toreceve == null){
				throw new NoConnectionExecption();
			}
			return toreceve;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new Message("Erreur", "Erreur");
	}
	private String read() throws IOException{      

	    String response = "";

	    int stream;

	    byte[] b = new byte[65536];

	    stream = this.input.read(b);

	    response = new String(b, 0, stream);      

	    return response;

	} 



}
