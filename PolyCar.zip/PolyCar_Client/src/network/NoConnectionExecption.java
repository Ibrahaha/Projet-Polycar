package network;

public class NoConnectionExecption extends Exception {

}
