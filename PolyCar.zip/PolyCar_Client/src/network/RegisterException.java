package network;

public class RegisterException extends Exception {}
