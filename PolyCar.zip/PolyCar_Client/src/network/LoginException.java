package network;

public class LoginException extends Exception {}
