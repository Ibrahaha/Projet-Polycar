package network;

public class Message {
	public String action;
	public String data;
	
	public Message(String action, String data) {
		this.action=action;
		this.data=data;
	}
	public String getAction() {
		return this.action;	
	}
	public String getData() {
		return this.data;
	}
	public void setAction(String action) {
		this.action=action;
	}
	public void setData(String data) {
		this.data = data;
	}
	
}
