package network;
import java.util.ArrayList;

import java.util.Calendar;

import java.util.Iterator;
import java.util.List;


import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import models.ModelLogin;
import models.ModelNotifications;
import models.ModelTrajets;
import models.ModelUtilisateur;
import models.Notification;
import models.Trajet;
import models.Utilisateur;

public class NetworkClient implements InterfaceNetworkClient {
	
	
	ModelUtilisateur modelUtilisateur;
	ModelTrajets modelTrajets;
	ModelUtilisateur modelProfile;
	ModelNotifications modelNotifications;
	ModelTrajets modelPropositionTrajet;
	Gson gson;
	ModelLogin modelLogin;
	Thread getNotif;
	int test;

	public NetworkClient(ModelUtilisateur modelUtilisateur, ModelTrajets modelTrajets, ModelUtilisateur modelProfile, ModelNotifications modelNotications, ModelTrajets modelPropositionTrajet, ModelLogin modelLogin) {
		this.modelUtilisateur = modelUtilisateur;
		this.modelTrajets = modelTrajets;
		this.modelProfile = modelProfile;
		this.modelNotifications = modelNotications;
		this.modelPropositionTrajet = modelPropositionTrajet;
		this.modelLogin = modelLogin;
		this.gson = new Gson();
		getNotif = new Thread(new Runnable(){
			@Override
			public void run(){
				while(!Thread.currentThread().isInterrupted()){
					while(modelLogin.getState()){
						try {
							Thread.sleep(5000);
						} catch (InterruptedException e) {
							
						}
						if(!modelLogin.getState()){
					        Thread.currentThread().interrupt();
						}
						getNotifications(modelUtilisateur.getUser());
					}
				}
			}
		});
		getNotif.start();
		
	}

	@Override
	public void login(String username, String password) throws LoginException {
		Envoi login = new Envoi(new Message("login", "{username :  "+ username +" , password : "+password+"}"));
		try {
			Message retour = login.call();
			String data = retour.getData();
			String action = retour.getAction();
			if(action.equals("login")) {
				modelLogin.setTrue();
				JsonObject jsonobject = gson.fromJson(data, JsonObject.class); 
				JsonObject user = (JsonObject) jsonobject.get("utilisateur");
				modelUtilisateur.setUtilisateur(gson.fromJson(user,Utilisateur.class));
				JsonArray notifs = jsonobject.get("notifications").getAsJsonArray();
				List<Notification> notifications = new ArrayList<Notification>();
				for(JsonElement notif : notifs){
					notifications.add(gson.fromJson(notif, Notification.class));
				}
				modelNotifications.setNotification(notifications);
			}
			else {
				throw new LoginException();
			}
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
			throw new LoginException();
		}

	}

	@Override
	public void register(Utilisateur user) throws RegisterException {
		Envoi envoi = new Envoi(new Message("register", "{utilisateur :  "+ gson.toJson(user) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			System.out.println(data);
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			boolean bool = gson.fromJson(jsonobject.get("inscription_valide"), Boolean.class);
			if(bool==false) {
				throw new RegisterException();
			}
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
			throw new RegisterException();
		}
	}

	@Override
	public void getTrajetsConducteur(Utilisateur user) {
		List<Trajet> trajets = new ArrayList<Trajet>();
		Envoi envoi = new Envoi(new Message("getTrajetsConducteur", "{utilisateur :  "+ gson.toJson(user) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray trajetsjson = jsonobject.get("trajets").getAsJsonArray();
			for(Iterator<JsonElement> it = trajetsjson.iterator() ; it.hasNext(); ) {
				trajets.add(gson.fromJson((JsonObject) it.next(), Trajet.class));
			}
			modelTrajets.setTrajets(trajets);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void getTrajetsPassager(Utilisateur user) {
		List<Trajet> trajets = new ArrayList<Trajet>();
		Envoi envoi = new Envoi(new Message("getTrajetsPassager", "{utilisateur :  "+ gson.toJson(user) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray trajetsjson = jsonobject.get("trajets").getAsJsonArray();
			for(Iterator<JsonElement> it = trajetsjson.iterator() ; it.hasNext(); ) {
				trajets.add(gson.fromJson((JsonObject) it.next(), Trajet.class));
			}
			modelTrajets.setTrajets(trajets);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void removeTrajet(Trajet trajet){
		List<Trajet> trajets = new ArrayList<Trajet>();
		Envoi envoi = new Envoi(new Message("removeTrajet", "{trajet :  "+ gson.toJson(trajet) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray trajetsjson = jsonobject.get("trajets").getAsJsonArray();
			for(Iterator<JsonElement> it = trajetsjson.iterator() ; it.hasNext(); ) {
				trajets.add(gson.fromJson((JsonObject) it.next(), Trajet.class));
			}
			modelTrajets.setTrajets(trajets);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}
	
	@Override
	public void addTrajet(Trajet trajet) {
		Envoi envoi = new Envoi(new Message("addTrajet", "{trajet :  "+ gson.toJson(trajet) +"}"));
		try {
			envoi.call();
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void findTrajet(Utilisateur user, String villeDep, String villeArr, Calendar date) {
		List<Trajet> trajets = new ArrayList<Trajet>();
		Envoi envoi = new Envoi(new Message("findTrajet", "{ville_depart :  "+ gson.toJson(villeDep) +
				", ville_arrivee : "+ gson.toJson(villeArr) +
				", date : " + gson.toJson(date)+
				", utilisateur : " + gson.toJson(user)+"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray trajetsjson = jsonobject.get("trajets").getAsJsonArray();
			for(Iterator<JsonElement> it = trajetsjson.iterator() ; it.hasNext(); ) {
				trajets.add(gson.fromJson((JsonObject) it.next(), Trajet.class));
			}
			modelPropositionTrajet.setTrajets(trajets);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}
	
	@Override
	public void registerTrajet(Utilisateur user, Trajet trajet){
		Envoi envoi = new Envoi(new Message("registerTrajet", "{trajet :  "+ gson.toJson(trajet) +
				", utilisateur : " + gson.toJson(user)+"}"));
		try {
			envoi.call();
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void cancelTrajet(Trajet trajet) {
		List<Trajet> trajets = new ArrayList<Trajet>();
		Envoi envoi = new Envoi(new Message("cancelTrajet", "{trajet :  "+ gson.toJson(trajet) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray trajetsjson = jsonobject.get("trajets").getAsJsonArray();
			for(Iterator<JsonElement> it = trajetsjson.iterator() ; it.hasNext(); ) {
				trajets.add(gson.fromJson((JsonObject) it.next(), Trajet.class));
			}
			modelTrajets.setTrajets(trajets);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void getNotifications(Utilisateur user) {
		Envoi envoi = new Envoi(new Message("getNotifications", "{utilisateur :  "+ gson.toJson(user) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray notificationsjson = jsonobject.get("notifications").getAsJsonArray();
			List<Notification> listNotifications = new ArrayList<Notification>();
			for(Iterator<JsonElement> it = notificationsjson.iterator() ; it.hasNext(); ) {
				listNotifications.add(gson.fromJson((JsonObject) it.next(), Notification.class));
			}
			modelNotifications.setNotification(listNotifications);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void deleteNotifications(List<Notification> notifications) {
		Envoi envoi = new Envoi(new Message("deleteNotifications", "{notifications :  "+ gson.toJson(notifications) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray notificationsjson = jsonobject.get("notifications").getAsJsonArray();
			List<Notification> listNotifications = new ArrayList<Notification>();
			for(Iterator<JsonElement> it = notificationsjson.iterator() ; it.hasNext(); ) {
				listNotifications.add(gson.fromJson((JsonObject) it.next(), Notification.class));
			}
			modelNotifications.setNotification(listNotifications);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void reportUserPassager(Utilisateur user) {
		Envoi envoi = new Envoi(new Message("reportUserPassager", "{utilisateur :  "+ gson.toJson(user) +"}"));
		try {
			envoi.call();
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void reportUserConducteur(Utilisateur user) {
		Envoi envoi = new Envoi(new Message("reportUserConducteur", "{utilisateur :  "+ gson.toJson(user) +"}"));
		try {
			envoi.call();
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void unregisterTrajet(Trajet trajet, Utilisateur user) {
		List<Trajet> trajets = new ArrayList<Trajet>();
		Envoi envoi = new Envoi(new Message("unregisterTrajet", "{trajet :  "+ gson.toJson(trajet) +
				", utilisateur : "+ gson.toJson(user)+"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			JsonArray trajetsjson = jsonobject.get("trajets").getAsJsonArray();
			for(Iterator<JsonElement> it = trajetsjson.iterator() ; it.hasNext(); ) {
				trajets.add(gson.fromJson((JsonObject) it.next(), Trajet.class));
			}
			modelTrajets.setTrajets(trajets);
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();			
		}
	}

	@Override
	public void updateUtilisateur(Utilisateur user) {
		Envoi envoi = new Envoi(new Message("updateUtilisateur", "{utilisateur : "+ gson.toJson(user) +"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			modelUtilisateur.setUtilisateur(gson.fromJson((JsonObject) jsonobject.get("utilisateur"), Utilisateur.class));
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void addFriend(Utilisateur myUser, Utilisateur friendUser) {
		Envoi envoi = new Envoi(new Message("addFriend", "{my_utilisateur :  "+ gson.toJson(myUser) + 
				", friend_utilisateur : "+ gson.toJson(friendUser)+"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			modelUtilisateur.setUtilisateur(gson.fromJson((JsonObject) jsonobject.get("my_utilisateur"), Utilisateur.class));
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void removeFriend(Utilisateur myUser, Utilisateur friendUser) {
		Envoi envoi = new Envoi(new Message("removeFriend", "{my_utilisateur :  "+ gson.toJson(myUser) + 
				", friend_utilisateur : "+ gson.toJson(friendUser)+"}"));
		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			modelUtilisateur.setUtilisateur(gson.fromJson((JsonObject) jsonobject.get("my_utilisateur"), Utilisateur.class));
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}

	@Override
	public void getProfile(Utilisateur user) {
		Envoi envoi = new Envoi(new Message("getProfile", "{utilisateur : "+ gson.toJson(user) +"}"));

		try {
			Message retour = envoi.call();
			String data = retour.getData();
			JsonObject jsonobject = gson.fromJson(data, JsonObject.class);
			modelProfile.setUtilisateur(gson.fromJson((JsonObject) jsonobject.get("utilisateur"), Utilisateur.class));
		} catch (NoConnectionExecption e) {
			modelLogin.setFalse();
		}
	}
}