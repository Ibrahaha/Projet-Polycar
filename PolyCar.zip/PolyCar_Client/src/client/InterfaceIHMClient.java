package client;

public interface InterfaceIHMClient {

	/**
	 * Lance une IHM client.
	 */
	void run();
}

