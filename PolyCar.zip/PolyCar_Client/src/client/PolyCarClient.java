package client;

public class PolyCarClient {

	public static void main(String[] args) {

		InterfaceIHMClient ihm = new IHMClient();
		ihm.run();
	}
}
