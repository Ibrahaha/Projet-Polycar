package client;

import controlers.*;
import models.*;
import network.*;

public class IHMClient implements InterfaceIHMClient {

	@Override
	public void run() {
		
		java.util.Locale.setDefault(java.util.Locale.FRENCH);
		
		ModelUtilisateur modelUtilisateur = new ModelUtilisateur();
		ModelTrajets modelTrajets = new ModelTrajets();
		ModelNotifications modelNotifications = new ModelNotifications();
		ModelUtilisateur modelProfile = new ModelUtilisateur();
		ModelTrajets modelPropositionTrajet = new ModelTrajets();
		ModelLogin modelLogin = new ModelLogin();
		
		InterfaceNetworkClient networkClient = new NetworkClient(modelUtilisateur, modelTrajets, modelProfile, modelNotifications, modelPropositionTrajet, modelLogin);
		
		new ControlerGeneral(modelUtilisateur, modelTrajets, modelProfile, modelNotifications, modelPropositionTrajet, modelLogin, networkClient);

	}

}
