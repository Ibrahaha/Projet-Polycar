package models;

import java.util.Observable;

public class Model extends Observable {
	boolean running;
	
	public Model(){
		this.running = false;
	}

	public void setChanged(boolean bool) {
		if(this.running != bool) {
			this.running = bool;
			this.setChanged();
		}
		this.notifyObservers();
	}
	
	public void setTrue() {
		this.setChanged(true);
	}
	
	public void setFalse() {
		this.setChanged(false);
	}
	
	public boolean getState() {
		return this.running;
	}
	
	
	@Override
	public String toString() {
		return "("+this.running+")";
	}
	
	public void init(){
		this.setChanged();
		this.notifyObservers();
	}
}