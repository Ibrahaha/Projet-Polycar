package controlers;

import java.awt.event.ActionEvent;

import java.util.Observable;
import java.util.Observer;

import javax.swing.AbstractAction;
import javax.swing.Action;

import models.Model;
import network.Serveur;
import views.Vue;

public class Controler {

	public Vue vue;
	private Model model;
	Serveur serveur;
	
	public Controler(Model model){
		serveur = new Serveur();
		this.model = model;
		this.vue = new Vue();
		
		ActionStart actionStart = new ActionStart();
		this.vue.buttonStart.setAction(actionStart);
		ActionStop actionStop = new ActionStop();
		this.vue.buttonStop.setAction(actionStop);
		
		this.model.addObserver(actionStart);
		this.model.addObserver(actionStop);
	}
	public class ActionStart extends AbstractAction implements Observer{
		
		public ActionStart(){
			this.putValue(Action.NAME,"Start");
			
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			serveur.start();
			model.setTrue();
		}

		@Override
		public void update(Observable arg0, Object arg1) {
			if(model.getState()) {
				this.setEnabled(false);
			}
			else{
				this.setEnabled(true);
			}
		}
	}
	
	public class ActionStop extends AbstractAction implements Observer{
		
		public ActionStop(){
			this.putValue(Action.NAME,"Stop");
			
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			serveur.stop();
			model.setFalse();
			
		}

		@Override
		public void update(Observable arg0, Object arg1) {
			if(model.getState()) {
				this.setEnabled(true);
			}
			else{
				this.setEnabled(false);
			}
		}

	}
}
	