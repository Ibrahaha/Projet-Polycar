package controlers;
import java.awt.FlowLayout;

import javax.swing.JPanel;

import models.Model;
import views.VueGeneral;

public class ControlerGeneral {
	public ControlerGeneral(Model model) {
		VueGeneral viewGenral = new VueGeneral();
		Controler controler = new Controler(model);
		model.init();
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new FlowLayout());
		mainPanel.add(controler.vue);
		viewGenral.setContentPane(mainPanel);
		viewGenral.pack();
		
	}
}
