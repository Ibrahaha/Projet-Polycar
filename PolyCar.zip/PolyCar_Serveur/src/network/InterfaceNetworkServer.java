package network;


public interface InterfaceNetworkServer {
	/**
	 * D�marre le serveur
	 */
	void start();
	/**
	 * Arr�te le serveur
	 */
	void stop();
	/**
	 * 
	 * @param commande : il indique l'action que doit faire le serveur, et �x�cute l'action.
	 * @return Le r�sultat de l'action au client sur son mod�le.
	 */
	Message doAction(Message commande);
}
