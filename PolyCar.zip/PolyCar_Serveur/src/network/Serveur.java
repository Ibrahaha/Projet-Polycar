package network;

import java.io.IOException;

import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import dao.*;


public class Serveur implements Runnable, InterfaceNetworkServer {
	ServerSocket serverSocket;
	Thread t;
	List<Thread> clients = new ArrayList<Thread>();
	boolean stop = false;
	static Map <String, InterfaceDAO> actionsMap = new HashMap<>();
	/**
	 * Constructeur du serveur, il d�finit la map d'actions possible dans le serveur. 
	 */
	public Serveur(){
		actionsMap.put("login", new Login());
		actionsMap.put("register", new Register());
		actionsMap.put("getTrajetsConducteur", new GetTrajetsConducteur());
		actionsMap.put("getTrajetsPassager", new GetTrajetsPassager());
		actionsMap.put("addTrajet", new AddTrajet());
		actionsMap.put("findTrajet", new FindTrajet());
		actionsMap.put("cancelTrajet", new CancelTrajet());
		actionsMap.put("getNotifications", new GetNotifications());
		actionsMap.put("deleteNotifications", new DeleteNotifications());
		actionsMap.put("reportUserPassager", new ReportUserPassager());
		actionsMap.put("reportUserConducteur", new ReportUserConducteur());
		actionsMap.put("unregisterTrajet", new UnregisterTrajet());
		actionsMap.put("updateUtilisateur", new UpdateUtilisateur());
		actionsMap.put("addFriend", new AddFriend());
		actionsMap.put("removeFriend", new RemoveFriend());
		actionsMap.put("getProfile", new GetProfile());
		actionsMap.put("removeTrajet", new RemoveTrajet());
		actionsMap.put("registerTrajet", new RegisterTrajet());
	}
	
	/**
	 * D�marre le serveur
	 */
	@Override
	public void start() {
		stop = false;
		try {
			this.serverSocket = new ServerSocket(4444, 100, InetAddress.getByName("127.0.0.1"));
		} catch (UnknownHostException e) {
			System.out.println("L'h�te est inconnu.");
		} catch (IOException e) {
			System.out.println("Erreur du serveur.");
		}
		t = new Thread(this);
		t.start();
		
	}
	
	/**
	 * Arr�te le serveur
	 */
	@Override
	public void stop() {
		try {
			serverSocket.close();
		} catch (IOException e) {
			System.out.println("Fermeture du serveur.");
			serverSocket = null;
		}
		stop = true;
		for(Iterator<Thread> it = clients.iterator(); it.hasNext(); ){
			try {
				((Thread) it.next()).join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			t.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	

	@Override
	public void run() {
		while(stop == false) {
			
			try {
				// On accepte la connexion entrante
				System.out.println("J'attends un client");
				Socket connexionCliente = serverSocket.accept();
			
				System.out.println("Un client se connecte au serveur.");
				Thread threadClient = new Thread(new ClientExecution(connexionCliente, this));
				clients.add(threadClient);
				threadClient.start();
				
			} catch (IOException e) {
				System.out.println("Erreur lors de la connexion du client");
				
			}
			
		}
		
	}
	
	public Message doAction(Message commande){
			synchronized(this){
				Message message_retour;
				
				try{
					message_retour = actionsMap.get(commande.getAction()).executerOperation(commande.getData());
					System.out.println(message_retour.getData());
				}catch(NullPointerException e){
					message_retour = null;
				}
				return message_retour;
			}
		
	}
	
}
