package network;

import java.io.BufferedInputStream;


import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;

import com.google.gson.Gson;


class ClientExecution implements Runnable {
	Socket socket;
	Serveur server;
	PrintWriter output;
	BufferedInputStream input;
	
	ClientExecution(Socket socket, Serveur server ){
		this.socket = socket;
		this.server = server;
	}

	@Override
	public void run() {
		System.out.println("D�but du traitement de la connexion entrante d'un client.");

		try {
				
			// Initialisation pour g�rer les entr�es / sorties
			this.output = new PrintWriter(this.socket.getOutputStream());
			this.input = new BufferedInputStream(this.socket.getInputStream());

			String reponseDuClient = read();
				
			System.out.println(reponseDuClient);
			Gson gson = new Gson();
			Message message_recu = gson.fromJson(reponseDuClient, Message.class);
							
				
			// TODO DEBUGGAGE
			InetSocketAddress remote = (InetSocketAddress) this.socket.getRemoteSocketAddress();
			System.err.println("Thread : " + Thread.currentThread().getName() + "\n");
			System.err.println("Demande de l'adresse : " + remote.getAddress().getHostAddress() + "\n");
			System.err.println("Sur le port : " + remote.getPort() + "\n");
			System.err.println("Commande re�ue : " + reponseDuClient + "\n");
			
			String messageToSend = gson.toJson(this.server.doAction(message_recu));
			this.output.write(messageToSend);
			this.output.flush();
				
			this.output = null;
			this.input = null;
			this.socket.close();
			
		}catch (SocketException e) {
			System.err.println("Erreur de connexion.");		
		}catch (IOException e) {
			System.err.println("Erreur d'entr�e / sortie.");
		}
		System.err.println("Fermeture de la connexion...");
	}
		
	
	
	 private String read() throws IOException{      

	      String response = "";

	      int stream;

	      byte[] b = new byte[65536];

	      stream = this.input.read(b);

	      response = new String(b, 0, stream);      

	      return response;

	   }
}
