package views;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class VueGeneral extends JFrame {
	
	public VueGeneral() {
		
		this.setIconImage(new ImageIcon(this.getClass().getClassLoader().getResource("images/icon_polycar.png")).getImage());
		this.setResizable(false);
		this.setTitle("Polycar-Serveur");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
}
