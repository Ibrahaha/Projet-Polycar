package views;

import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Vue extends JPanel{
	public JPanel panelButtons;
	public JPanel panelImage;
	public JLabel labelimage;
	public JButton buttonStart;
	public JButton buttonStop;
	
	public Vue() {
		JPanel panelContainer = new JPanel();
		panelContainer.setLayout(new BoxLayout(panelContainer, BoxLayout.Y_AXIS));
		
		this.labelimage= new JLabel(new ImageIcon(this.getClass().getClassLoader().getResource("images/logo_polycar.png")));
		this.buttonStart= new JButton();
		this.buttonStop= new JButton();
		
		this.panelImage = new JPanel();
		this.panelButtons = new JPanel();
		this.panelButtons.setLayout(new GridLayout(1,2));
		
		//ajout des boutons et labels
		this.panelImage.add(labelimage);
		this.panelButtons.add(buttonStart);
		this.panelButtons.add(buttonStop);
		
		
		
		panelContainer.add(this.panelImage);
		panelContainer.add(this.panelButtons);
		
		this.add(panelContainer);
		
		
	}
	

}
