package serveur;

public interface InterfaceIHMServeur {

	/**
	 * Lance une IHM serveur.
	 */
	void run();
}
