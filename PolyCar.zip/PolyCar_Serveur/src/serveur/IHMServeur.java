package serveur;

import controlers.ControlerGeneral;
import models.Model;

public class IHMServeur implements InterfaceIHMServeur {

	@Override
	public void run() {
		Model model = new Model();
		new ControlerGeneral(model);

	}

}
