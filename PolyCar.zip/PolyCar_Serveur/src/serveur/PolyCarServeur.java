package serveur;

public class PolyCarServeur {

	public static void main(String[] args) {
		InterfaceIHMServeur ihm = new IHMServeur();
		ihm.run();
	}
}
