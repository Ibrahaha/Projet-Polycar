package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class GetNotifications implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("getNotifications", "{notifications:[]}");
		Gson gson = new Gson();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
				
		String username_user = ((JsonObject) data_object.get("utilisateur")).get("username").getAsString();
		

		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_notifications));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileNotifications();
				br = new BufferedReader(new FileReader(Utilitaires.path_notifications));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
					
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body_notif = gson.fromJson(br, JsonObject.class);
				
		// On r�cup�re la liste des notifications
		JsonArray notifications = body_notif.get("notifications").getAsJsonArray();
		
		JsonArray notifications_users = new JsonArray();
		
		// On parcours notre tableau pour r�cup�rer les diff�rentes notifications de l'utilisateur
		for (Iterator<JsonElement> iterator = notifications.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();

			if(username_user.equals(current.get("usernameDestinataire").getAsString())) {
				notifications_users.add(current);
			}

		}
		
		message.setData("{notifications:" + notifications_users + "}");
		
		try {
			br.close();
		} catch (IOException e) {
			
		}
		
		return message;
	}
	

}
