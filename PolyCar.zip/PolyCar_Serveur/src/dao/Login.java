package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class Login implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("login", "{utilisateur:\"\", notifications:[]}");
		Gson gson = new Gson();
		
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_utilisateurs));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileUsers();
				br = new BufferedReader(new FileReader(Utilitaires.path_utilisateurs));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des utilisateurs
		JsonArray utilisateurs = body.get("utilisateurs").getAsJsonArray();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
				
		String username_user = data_object.get("username").getAsString();
		String password_user = data_object.get("password").getAsString();
		
		JsonObject utilisateur_a_renvoyer = null;

			
		// On parcours notre objet jusqu'� trouver l'employ� recherch�
		for (Iterator<JsonElement> iterator = utilisateurs.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();

			if(username_user.equals(current.get("username").getAsString())) {
				if(! password_user.equals(current.get("password").getAsString())){
					try {
						message.setAction("erreur");
						message.setData("Les identifiants ne correspondent pas.");
						br.close();
						return message;
					} catch (IOException e) {
						return message;
					}
				}else{
					utilisateur_a_renvoyer = current;
				}
				break;
			}

		}
		
		try {
			br.close();
		} catch (IOException e) {
			
		}
		
		if(utilisateur_a_renvoyer == null){
			message.setAction("erreur");
			message.setData("Identifiants incorrects.");
			return message;
		}
		
		
		// Utilisateur trouv� --> on va rechercher les notifications �galement
		// Lecture du fichier
		br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_notifications));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileNotifications();
				br = new BufferedReader(new FileReader(Utilitaires.path_notifications));
			} catch (FileNotFoundException e1) {
				message.setData("{utilisateur: " + utilisateur_a_renvoyer + ", notifications:[]}");
				return message;
			}
		}

		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body_notif = gson.fromJson(br, JsonObject.class);
				
		// On r�cup�re la liste des notifications
		JsonArray notifications = body_notif.get("notifications").getAsJsonArray();
		
		JsonArray notifications_users = new JsonArray();
		
		// On parcours notre objet jusqu'� trouver l'employ� recherch�
		for (Iterator<JsonElement> iterator = notifications.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();

			if(username_user.equals(current.get("usernameDestinataire").getAsString())) {
				notifications_users.add(current);
			}

		}
		
		message.setData("{utilisateur: " + utilisateur_a_renvoyer + ", notifications:" + notifications_users + "}");
		
		try {
			br.close();
		} catch (IOException e) {
			
		}
		
		
		return message;
	}
	

}
