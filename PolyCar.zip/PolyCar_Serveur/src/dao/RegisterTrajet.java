package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class RegisterTrajet implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		
		Message message = new Message("registerTrajet", "{trajets:[]}");
		Gson gson = new Gson();
		System.out.println("--------------------");
		System.out.println(data);
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileTrajets();
				br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des trajets
		JsonArray trajets = body.get("trajets").getAsJsonArray();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
				
		JsonObject register_trajet = (JsonObject) data_object.get("trajet");
		int id_trajet = register_trajet.get("id").getAsInt();
		
		JsonObject utilisateur = (JsonObject) data_object.get("utilisateur");
		
		String username_user = utilisateur.get("username").getAsString();
				
		JsonArray trajets_du_passager = new JsonArray();
				
		// On parcourt les trajets pour retourner ceux du passager
		for (Iterator<JsonElement> iterator = trajets.iterator(); iterator.hasNext();) {
			
			JsonObject current = (JsonObject) iterator.next();

			JsonArray passagers = current.get("listePassagers").getAsJsonArray();

			// On ajoute l'utilisateur dans les passagers du trajet souhait�
			if(id_trajet == current.get("id").getAsInt()) {
				passagers.add(utilisateur);
				trajets_du_passager.add(current);

				
			}else {
				// On regarde si on est passager du trajet
				for (Iterator<JsonElement> iterator_passagers = passagers.iterator(); iterator_passagers.hasNext();) {
					JsonObject passager = (JsonObject) iterator_passagers.next();
					if(passager.get("username").getAsString().equals(username_user)){
						trajets_du_passager.add(current);
					}
				}
			}
		}
		
		message.setData("{trajets:" + trajets_du_passager + "}");

		// On r��crit dans le fichier apr�s que la modification a �t� effectu�e
		String json = gson.toJson(body);
		
		FileWriter fw = null;
		try {
			fw = new FileWriter(Utilitaires.path_trajets);
			fw.write(json);
		} catch (IOException e) {
			message.setData("{trajets:[]}");
		}
		
		try {
			fw.close();
			br.close();
		} catch (IOException e) {
			// On renverra les trajets 
		}
		
				
		return message;
		
	}
	

}
