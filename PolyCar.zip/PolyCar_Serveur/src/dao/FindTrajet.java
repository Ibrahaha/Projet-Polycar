package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Locale;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class FindTrajet implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("findTrajet", "{trajets:[]}");
		Gson gson = new Gson();
		
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileTrajets();
				br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
				
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
		
		String villeDepart = data_object.get("ville_depart").getAsString();
		String villeArrivee = data_object.get("ville_arrivee").getAsString();
		GregorianCalendar date = gson.fromJson(data_object.get("date"), GregorianCalendar.class);
		JsonArray amis = ((JsonObject) data_object.get("utilisateur")).get("listeAmis").getAsJsonArray();
		
		JsonArray trajets = body.get("trajets").getAsJsonArray();
		
		JsonArray trajets_trouves = new JsonArray();
		JsonArray trajets_trouves_amis = new JsonArray();

		boolean conductAmi = false;
		
		// On parcours les trajets pour trouver ceux correspondant � la recherche
		for (Iterator<JsonElement> iterator = trajets.iterator(); iterator.hasNext();) {
						
			JsonObject current = (JsonObject) iterator.next();
			
			GregorianCalendar date_cur = gson.fromJson((JsonObject) current.get("dateDepart"), GregorianCalendar.class);

			if(date_cur.get(Calendar.YEAR) == date.get(Calendar.YEAR)
			&& date_cur.get(Calendar.DAY_OF_YEAR) == date.get(Calendar.DAY_OF_YEAR)){
				
				// On cr�� un tableau rassemblant les villes de d�part, d'arriv�e et des �tapes
				ArrayList<String> toutes_etapes = new ArrayList<String>();
				toutes_etapes.add(current.get("villeDepart").getAsString());
				
				JsonArray etapes = current.get("etapes").getAsJsonArray();
				
				for (Iterator<JsonElement> iterator_etapes = etapes.iterator(); iterator_etapes.hasNext();) {
					JsonObject current_etape = (JsonObject) iterator_etapes.next();
					toutes_etapes.add(current_etape.get("ville").getAsString());
				}
				
				toutes_etapes.add(current.get("villeArrivee").getAsString());
				
				// Indique si on a trouv� la ville de d�part correspondant au trajet
				boolean departCorrespondant = false;
				
				for(String nomVilleCourante : toutes_etapes){
					
					// Si on trouve une ville correspondant � la ville de d�part
					if(!departCorrespondant && stringCompare(villeDepart, nomVilleCourante)){
						departCorrespondant = true;
					}
					// Si on a trouv� un trajet correspondant
					else if(departCorrespondant == true && stringCompare(villeArrivee, nomVilleCourante)){
						
						// On va v�rifier si le conducteur est un des amis de l'utilisateur ou non
						JsonObject conducteur = (JsonObject) current.get("conducteur");
						String username_conducteur = conducteur.get("username").getAsString();
						
						conductAmi = false;
						
						for (Iterator<JsonElement> iterator_ami = amis.iterator(); iterator_ami.hasNext();) {
							
							JsonObject current_ami = (JsonObject) iterator_ami.next();

							// Si le conducteur est un de nos amis
							if(username_conducteur.equals(current_ami.get("username"))) {
								trajets_trouves_amis.add(current);
								conductAmi = true;
								break;
							}

						}
						// Si le conducteur n'est pas un de nos amis
						if(conductAmi == false) {
							trajets_trouves.add(current);	
						}
						
						break;
						
					}
				}

			}
		
		}
		
		trajets_trouves_amis.addAll(trajets_trouves);
		
		message.setData("{trajets:" + trajets_trouves_amis + "}");
		
		try {
			br.close();
		} catch (IOException e) {
			
		}

		return message;
	}
	
	public static boolean stringCompare(String s1, String s2){
        Collator myCollator = Collator.getInstance(Locale.US);
        myCollator.setStrength(Collator.PRIMARY);
        return myCollator.compare(s1,s2) == 0;
        
    }


}
