package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class RemoveTrajet implements InterfaceDAO{

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("removeTrajet", "{trajets:[]}");
		Gson gson = new Gson();
				
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileTrajets();
				br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}

		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des trajets et le nombre de trajets
		JsonArray trajets = body.get("trajets").getAsJsonArray();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
				
		JsonObject trajet_a_retirer = (JsonObject) data_object.get("trajet");
		
		JsonObject conducteur = (JsonObject)trajet_a_retirer.get("conducteur");
		String nom_conducteur = conducteur.get("username").getAsString();
				
		JsonArray trajets_du_conducteur = new JsonArray();
		
		// On parcours les trajets pour retourner ceux du conducteur et retirer celui souhait�
		for (Iterator<JsonElement> iterator = trajets.iterator(); iterator.hasNext();) {
			
			JsonObject current = (JsonObject) iterator.next();
			
			if(trajet_a_retirer.get("id").getAsInt()==current.get("id").getAsInt()) {
				iterator.remove();
			}else{
				JsonObject current_conducteur = (JsonObject) current.get("conducteur");
				if(nom_conducteur.equals(current_conducteur.get("username").getAsString())) {
					trajets_du_conducteur.add(current);
				}
			}

		}
		
		message.setData("{trajets:" + trajets_du_conducteur + "}");

		// On r��crit dans le fichier apr�s que la modification a �t� effectu�e
		String json = gson.toJson(body);
		
		FileWriter fw = null;
		try {
			fw = new FileWriter(Utilitaires.path_trajets);
			fw.write(json);
		} catch (IOException e) {
			message.setData("{trajets:[]}");
		}
		
		try {
			fw.close();
			br.close();
		} catch (IOException e) {
			// On renverra les trajets 
		}
		
   

		return message;
		
	}
	

}
