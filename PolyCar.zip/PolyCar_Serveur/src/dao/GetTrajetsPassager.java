package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class GetTrajetsPassager implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("getTrajetsPassager", "{trajets:[]}");
		Gson gson = new Gson();
		
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileTrajets();
				br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des trajets et le nombre de trajets
		JsonArray trajets = body.get("trajets").getAsJsonArray();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
						
		String username_user = ((JsonObject) data_object.get("utilisateur")).get("username").getAsString();
				
		JsonArray trajets_du_passager = new JsonArray();
		
		// On parcourt les trajets pour retourner ceux du passager
		for (Iterator<JsonElement> iterator = trajets.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();
			JsonArray passagers = current.get("listePassagers").getAsJsonArray();
			// On parcourt la liste des passagers du trajet courant
			for (Iterator<JsonElement> iterator_passager = passagers.iterator(); iterator_passager.hasNext();) {
				
				JsonObject current_passager = (JsonObject) iterator_passager.next();
				if(username_user.equals(current_passager.get("username").getAsString())) {
					trajets_du_passager.add(current);
				}
	
			}
			
		
		}
		
		
		
		try {
			message.setData("{trajets:" + trajets_du_passager + "}");
			br.close();
		} catch (IOException e) {
			
		}

		return message;
		
	}
	

}
