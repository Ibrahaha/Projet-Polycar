package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class GetProfile implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("getProfile", "{utilisateur:\"\"}");
		Gson gson = new Gson();
		
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_utilisateurs));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileUsers();
				br = new BufferedReader(new FileReader(Utilitaires.path_utilisateurs));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des utilisateurs
		JsonArray utilisateurs = body.get("utilisateurs").getAsJsonArray();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
				
		JsonObject my_utilisateur_user = (JsonObject) data_object.get("utilisateur");
			
		// On parcours notre objet jusqu'� trouver l'employ� recherch�
		for (Iterator<JsonElement> iterator = utilisateurs.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();

			if(my_utilisateur_user.get("username").getAsString().equals(current.get("username").getAsString())) {
				message.setData("{utilisateur: " + current + "}");
				break;
			}

		}
		
		try {
			br.close();
		} catch (IOException e) {
			
		}

		return message;
	}
	
}
