package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class DeleteNotifications implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("deleteNotifications", "{notifications:[]}");
		Gson gson = new Gson();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);

		JsonArray notifications_a_supprimer = data_object.get("notifications").getAsJsonArray();
		ArrayList<Integer> id_notifications_a_supprimer = new ArrayList<Integer>();
		String username_user;
		
		username_user = "";
		
		for (Iterator<JsonElement> iterator = notifications_a_supprimer.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();
			id_notifications_a_supprimer.add(current.get("id").getAsInt());
			if(username_user == "") {
				username_user = current.get("usernameDestinataire").getAsString();
			}
		}
		
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_notifications));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileNotifications();
				br = new BufferedReader(new FileReader(Utilitaires.path_notifications));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
				
		// On r�cup�re la liste des notifications
		JsonArray notifications = body.get("notifications").getAsJsonArray();
		
		
		
		JsonArray notifications_users = new JsonArray();
		int index;
		// On parcours notre tableau pour r�cup�rer les diff�rentes notifications de l'utilisateur
		for (Iterator<JsonElement> iterator = notifications.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();
			
			if((index = id_notifications_a_supprimer.indexOf(current.get("id").getAsInt())) >= 0) {
				id_notifications_a_supprimer.remove(index);
				iterator.remove();
			}
			else if(username_user.equals(current.get("usernameDestinataire").getAsString())) {
				notifications_users.add(current);
			}

		}
			
	
		message.setData("{notifications:" + notifications_users + "}");
		
		// On r��crit dans le fichier apr�s que la modification a �t� effectu�e
		String json = gson.toJson(body);
		
		FileWriter fw = null;
		try {
			fw = new FileWriter(Utilitaires.path_notifications);
			fw.write(json);
		} catch (IOException e) {
			message.setData("{notifications:[]}");
		}
		
		try {
			fw.close();
			br.close();
		} catch (IOException e) {
			// On renverra les notifications 
		}
		
		
		return message;
	}
	

}
