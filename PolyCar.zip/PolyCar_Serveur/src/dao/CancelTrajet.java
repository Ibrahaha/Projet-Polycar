package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class CancelTrajet implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("cancelTrajet", "{trajets:[]}");
		Gson gson = new Gson();
			
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileTrajets();
				br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des trajets et le nombre de trajets
		JsonArray trajets = body.get("trajets").getAsJsonArray();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
				
		JsonObject cancel_trajet = (JsonObject) data_object.get("trajet");
		
		JsonObject conducteur = (JsonObject)cancel_trajet.get("conducteur");
		String nom_conducteur = conducteur.get("username").getAsString();

		JsonArray trajets_du_conducteur = new JsonArray();
		
		ArrayList<String> liste_passagers_username = new ArrayList<String>();
				
		// On parcours les trajets pour retourner ceux du conducteur et supprimer celui souhait�
		for (Iterator<JsonElement> iterator = trajets.iterator(); iterator.hasNext();) {
			
			JsonObject current = (JsonObject) iterator.next();

			if(cancel_trajet.get("id").getAsInt() == current.get("id").getAsInt()) {

				// On va enregistrer tous les passagers
				JsonArray passagers = current.get("listePassagers").getAsJsonArray();
				for (Iterator<JsonElement> iterator_passagers = passagers.iterator(); iterator_passagers.hasNext();) {
					JsonObject passager = (JsonObject) iterator_passagers.next();
					liste_passagers_username.add(passager.get("username").getAsString());				
				}
				
				iterator.remove();
				
			}else {
				JsonObject current_conducteur = (JsonObject) current.get("conducteur");
				if(nom_conducteur.equals(current_conducteur.get("username").getAsString())) {
					trajets_du_conducteur.add(current);
				}
			}

		}
		
		message.setData("{trajets:" + trajets_du_conducteur + "}");

		// On r��crit dans le fichier apr�s que la modification a �t� effectu�e
		String json = gson.toJson(body);

		FileWriter fw = null;
		try {
			fw = new FileWriter(Utilitaires.path_trajets);
			fw.write(json);
		} catch (IOException e) {
			message.setData("{trajets:[]}");
		}
		
		try {
			fw.close();
			br.close();
		} catch (IOException e) {
			// On renverra les trajets 
		}
		
		
		// On �crit les notifications des passagers
		BufferedReader br2 = null;
		try {
			br2 = new BufferedReader(new FileReader(Utilitaires.path_notifications));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileNotifications();
				br2 = new BufferedReader(new FileReader(Utilitaires.path_notifications));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}

		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body_notif = gson.fromJson(br2, JsonObject.class);
		// On r�cup�re la liste des notifications
		JsonArray notifications = body_notif.get("notifications").getAsJsonArray();
		int nb_notifs = body_notif.get("nbNotifications").getAsInt();

		// On r�cup�re la date du trajet
		GregorianCalendar dateTrajet = gson.fromJson(cancel_trajet.get("dateDepart"), GregorianCalendar.class);
		SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
		String dateTrajet_string = format.format(dateTrajet.getTime());
		
		for(String username: liste_passagers_username) {
			JsonObject notification = new JsonObject();
			notification.addProperty("id", nb_notifs);
			notification.addProperty("notification", "Attention, le trajet " + cancel_trajet.get("villeDepart").getAsString() + "-" + cancel_trajet.get("villeArrivee").getAsString() + " du " + dateTrajet_string + " a �t� annul�.");
			notification.addProperty("usernameDestinataire", username);
			notifications.add(notification);
			nb_notifs++;
		}
			
		// On incr�mente le nombre de notifications dans le fichier
		body_notif.addProperty("nbNotifications", nb_notifs);
		
		// On �crit les notifications dans le fichier
		fw = null;
		json = gson.toJson(body_notif);

		try {
			fw = new FileWriter(Utilitaires.path_notifications);
			fw.write(json);
			fw.close();
			br2.close();
		} catch (IOException e) {

		}
		
		return message;
		
	}
	
}
