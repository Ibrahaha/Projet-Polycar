package dao;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Utilitaires {
	
	static final String path_utilisateurs = "./utilisateurs.json";
	static final String path_trajets = "./trajets.json";
	static final String path_notifications = "./notifications.json";
	
	private static boolean fileExist(String path_file){
		Path path = Paths.get(path_file);
		return Files.exists(path);
	}
	
	private static void createFileJson(String path, String content) throws FileNotFoundException{
		PrintWriter writer = null;
		try{
			writer = new PrintWriter(path, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			writer = new PrintWriter(path);
		}
		writer.println(content);
		writer.close();
	}
	
	public static boolean fileUsersExist(){
		return fileExist(path_utilisateurs);
	}
	
	public static boolean fileTrajetsExist(){
		return fileExist(path_trajets);
	}

	public static boolean fileNotificationsExist(){
		return fileExist(path_notifications);
	}
	
	public static void createFileUsers() throws FileNotFoundException{
		createFileJson(path_utilisateurs, "{\"utilisateurs\":[]}");
	}
	
	public static void createFileTrajets() throws FileNotFoundException{
		createFileJson(path_trajets, "{\"nbTrajets\":0,\"trajets\":[]}");
	}
	
	public static void createFileNotifications() throws FileNotFoundException{
		createFileJson(path_notifications, "{\"nbNotifications\":0,\"notifications\":[]}");
	}
	
	
}
