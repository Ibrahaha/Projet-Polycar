package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class GetTrajetsConducteur implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		Message message = new Message("getTrajetsConducteur", "{trajets:[]}");
		Gson gson = new Gson();
		// Lecture du fichier
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileTrajets();
				br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des trajets et le nombre de trajets
		JsonArray trajets = body.get("trajets").getAsJsonArray();
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
						
		String username_user = ((JsonObject) data_object.get("utilisateur")).get("username").getAsString();
				
		JsonArray trajets_du_conducteur = new JsonArray();
		
		// On parcours les trajets pour retourner ceux du conducteur
		for (Iterator<JsonElement> iterator = trajets.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();
			JsonObject current_conducteur = (JsonObject) current.get("conducteur");
			if(username_user.equals(current_conducteur.get("username").getAsString())) {
				System.out.println("aa");
				trajets_du_conducteur.add(current);
			}

		}
		
		
		
		try {
			message.setData("{trajets:" + trajets_du_conducteur + "}");
			br.close();
		} catch (IOException e) {
			
		}

		return message;
		
	}

}
