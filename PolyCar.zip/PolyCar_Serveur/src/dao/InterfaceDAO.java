package dao;

import network.Message;

/**
 * Interface permettant d'ex�cuter une op�ration du DAO (d'entr�e / sortie)
 * @author E155424P
 *
 */
public interface InterfaceDAO {

	/**
	 * M�thode permettant d'ex�cuter une op�ration du DAO d'entr�e / sortie
	 * @param data les donn�es � traiter
	 * @return un objet Message contenant l'action r�alis�e (ou une erreur) et les donn�es demand�es 
	 */
	Message executerOperation(String data);
	
	
}
