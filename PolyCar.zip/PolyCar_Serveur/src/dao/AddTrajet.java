package dao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import network.Message;

public class AddTrajet implements InterfaceDAO {

	@Override
	public Message executerOperation(String data) {
		
		Message message = new Message("addTrajet", "{trajets:[]}");
		Gson gson = new Gson();
		
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
		} catch (FileNotFoundException e) {
			try {
				Utilitaires.createFileTrajets();
				br = new BufferedReader(new FileReader(Utilitaires.path_trajets));
			} catch (FileNotFoundException e1) {
				return message;
			}
		}
		
		// On r�cup�re le contenu du fichier json et on le transforme en JsonObject
		JsonObject body = gson.fromJson(br, JsonObject.class);
		
		// On r�cup�re la liste des trajets et le nombre de trajets
		JsonArray trajets = body.get("trajets").getAsJsonArray();
		JsonElement nb_trajets_objet = body.get("nbTrajets");
		
		// On transforme les data en JsonObject
		JsonObject data_object = gson.fromJson(data, JsonObject.class);
				
		JsonObject trajet_a_ajoute = (JsonObject) data_object.get("trajet");

		
		int nb_trajets = nb_trajets_objet.getAsNumber().intValue();
		
		// Le trajet � ajouter correspond au nombre de trajets pr�sents avant l'ajout
		trajet_a_ajoute.addProperty("id", nb_trajets);
		
		nb_trajets++;
		// On incr�mente le nombre de trajets dans le fichier
		body.addProperty("nbTrajets", nb_trajets);
		
		JsonObject conducteur = (JsonObject)trajet_a_ajoute.get("conducteur");
		
		JsonArray trajets_du_conducteur = new JsonArray();

		// On ajoute le trajet
		trajets.add(trajet_a_ajoute);
		
		trajets_du_conducteur.add(trajet_a_ajoute);
		
		// On parcours les trajets pour retourner ceux du conducteur
		for (Iterator<JsonElement> iterator = trajets.iterator(); iterator.hasNext();) {
			JsonObject current = (JsonObject) iterator.next();
			JsonObject current_conducteur = (JsonObject) current.get("conducteur");
			if(conducteur.get("username").getAsString().equals(current_conducteur.get("username").getAsString())) {
				trajets_du_conducteur.add(current);
			}

		}
		
		message.setData("{trajets:" + trajets_du_conducteur + "}");

		// On r��crit dans le fichier apr�s que la modification a �t� effectu�e
		String json = gson.toJson(body);

        FileWriter fw = null;
		try {
			fw = new FileWriter(Utilitaires.path_trajets);
			fw.write(json);
		} catch (IOException e) {
			message.setData("{trajets:[]}");
		}
		
		try {
			fw.close();
			br.close();
		} catch (IOException e) {
			// On renverra les trajets 
		}

		return message;
		
	}
	
	
}
